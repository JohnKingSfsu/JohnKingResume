# Credentials Folder

## The purpose of this folder is to store all credentials needed to log into your server and databases. This is important for many reasons. But the two most important reasons is
    1. Grading , servers and databases will be logged into to check code and functionality of application. Not changes will be unless directed and coordinated with the team.
    2. Help. If a class TA or class CTO needs to help a team with an issue, this folder will help facilitate this giving the TA or CTO all needed info AND instructions for logging into your team's server. 


# Below is a list of items required. Missing items will causes points to be deducted from multiple milestone submissions.

## The following information is stored in corresponding txt files. The production server needs to be accessed using the SSH key file with the -i option. 
1. Server URL or IP: server-ip.txt
2. SSH username: ssh-user.txt
3. SSH password or key: admin.pem
    <br> If a ssh key is used please upload the key to the credentials folder.
4. Database URL or IP and port used: db-ip.txt 
    <br><strong> NOTE THIS DOES NOT MEAN YOUR DATABASE NEEDS A PUBLIC FACING PORT.</strong> But knowing the IP and port number will help with SSH tunneling into the database. The default port is more than sufficient for this class.
5. Database username: db-user.txt
6. Database password: db-password.txt
7. Database name (basically the name that contains all your tables): db-name.txt
8. Instructions on how to use the above information.

## Instructions on how to access the server and database 
1. You will need to ssh into the server with
```ssh -i admin.pem [ssh-user.txt]@[server-ip.txt]```
2. After that you can use the mysql shell or client of your choice to connect with the provided credentials in this file. 

# Most important things to Remember
## These values need to kept update to date throughout the semester. <br>
## <strong>Failure to do so will result it points be deducted from milestone submissions.</strong><br>
## You may store the most of the above in this README.md file. DO NOT Store the SSH key or any keys in this README.md file.
