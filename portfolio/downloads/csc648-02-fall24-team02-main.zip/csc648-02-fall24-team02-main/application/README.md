# CSC 648 Team 02 Voting App Instructions

## Development

Install the following dependencies:

### Bun

For WSL and Linux users on Ubuntu:

```sh
sudo apt-get install unzip
curl -fsSL https://bun.sh/install | bash
```

For MacOS users running Brew:

```sh
brew install oven-sh/bun/bun
```

### Docker and Docker Compose

For WSL and Linux users on Ubuntu:
https://docs.docker.com/engine/install/ubuntu/

For MacOS users running Brew:

```sh
brew install --cask docker
brew install docker-compose
```

### Run the dev server and database:

Make sure you are in the correct directory:

```sh
cd application
```

If this is your first time running the dev server:

```sh
cp example.env .env
bun install
```

Otherwise run the following:

```sh
bun run dev
```

The dev server will now take up the terminal until you exit it so open a new terminal:

```sh
docker compose up -d
```

Note for MacOS users, you will need to have the Docker app running. This was downloaded through Brew.

### Exiting the dev server:

```sh
docker compose down
```

## Simulate Production Environment

In order to simulate the production on your local machine:

```sh
docker compose --profile production up -d --build
```

### Exiting the dev server:

```sh
docker compose --profile production down
```

Note: The database created will be running on PORT 3306. Make sure you do not
have any apps running on 3306 or it will NOT deploy. MariaDB and MySQL DB
typically use this port.

The application will be proxied by our reverse proxy onto the default port 80.
You can access the site at: http://localhost or http://127.0.01
