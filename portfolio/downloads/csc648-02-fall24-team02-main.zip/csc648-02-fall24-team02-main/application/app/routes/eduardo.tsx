export default function Info() {
    return (
        <div style={{ textAlign: 'center', }}>
        <h1> 
            <strong>Eduardo Rodriguez</strong></h1>
        <br></br>
        <p>My name is Eduardo and I am a senior at SFSU.</p>
        <p>I am the backend lead developer</p>
        <p>Some of my hobbies are playing soccer and playing pool </p>
      </div>
    )
  }
