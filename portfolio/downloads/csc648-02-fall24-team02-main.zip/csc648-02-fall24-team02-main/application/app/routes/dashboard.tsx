import { LoaderFunctionArgs } from "@remix-run/node"
import { useLoaderData } from "@remix-run/react"
import { getElectionsForUser } from "backend/models/election"
import { User } from "backend/models/user"
import { authenticator } from "backend/services/auth/auth"

export async function loader({ request }: LoaderFunctionArgs) {
  const user = await authenticator.isAuthenticated(request, {
    failureRedirect: "/login",
  })
  const electionsVotedIn = await getElectionsForUser(user.id)
  console.log(electionsVotedIn)

  return { user, electionsVotedIn }
}

export default function Dashboard() {
  const { user, electionsVotedIn } = useLoaderData<typeof loader>()

  return (
    <div className="flex flex-col bg-slate-100 mx-4">
      <div className="p-8 rounded-lg">
        <h1 className="text-3xl font-semibold text-pink-400 py-4">Dashboard</h1>
        <p className="font-medium text-xl">Welcome back, {user.firstName}</p>
        <p className="text-xl mt-5">
          If you want to send messages to your friends, please tell them your
          user id.
        </p>
        <p className="text-xl text-purple-500 font-semibold mt-4">
          Your user id is: {user.id}
        </p>
      </div>
      {electionsVotedIn?.length ? (
        <div className="p-8 rounded-lg">
          <h2 className="text-3xl font-semibold text-pink-400 my-4">
            Elections you voted in
          </h2>
          <ul>
            {electionsVotedIn.map((election) => (
                <div className={`shadow-md w-1/2 p-4 rounded-md ${
                election.users.party === 'Republican' ? 'bg-red-50' :
                election.users.party === 'Democrat' ? 'bg-blue-50' :
                'bg-slate-50'
                }`}>
                <li
                  key={election.elections.id}
                  className="text-xl font-semibold mt-2"
                >
                  {election.elections.title}
                </li>
                <p>
                  You voted for:{" "}
                  {election.users.firstName + " " + election.users.lastName}
                </p>
                </div>
            ))}
          </ul>
        </div>
      ) : (
        <h2 className="text-2xl font-semibold text-pink-400 my-4 text-center">
          You have not voted in any election yet.
        </h2>
      )}
    </div>
  )
}
