import {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  redirect,
} from "@remix-run/node"
import { Form, useActionData } from "@remix-run/react"
import { getSearchedUsers } from "backend/models/search"
import { getTotalRating } from "backend/services/rating/rating"
import { filter } from "compression"

export default function SearchPage() {
  const data = useActionData<typeof action>()
  return (
    <div className="flex flex-col items-center justify-center">
      <h1 className="text-4xl font-semibold">Search</h1>
      <Form method="POST" className="flex w-full md:w-3/4 p-4 join">
        <input
          name="search-query"
          type="text"
          className="input input-bordered w-full join-item"
          placeholder="Search"
        />
        <select
          name="search-filter"
          className="select select-bordered max-w-xs join-item"
        >
          <option value={""} disabled={true}>
            Filter
          </option>
          <option value={"name"}>Name</option>
          <option value={"location"}>Location</option>
          <option value={"position"}>Position</option>
          <option value={"party"}>Party</option>
        </select>
        <button className="btn join-item" type="submit">
          Search
        </button>
      </Form>
      <div className="flex flex-col p-4 gap-4 w-full items-center">
        {data
          ? data.map((user) => <SearchResult key={user.id} {...user} />)
          : "No results found"}
      </div>
    </div>
  )
}

type SearchResultProps = {
  id: number
  firstName: string
  lastName: string
  party: string
  city: string
  state: string
  picture: string
  rating: number
  position: string
}

function SearchResult({
  id,
  firstName,
  lastName,
  party,
  city,
  state,
  picture,
  rating,
  position,
}: SearchResultProps) {
  return (
    <div className="flex flex-col-reverse items-center md:flex-row justify-between p-5 rounded-lg shadow-md w-2/3 xl:w-1/2 border-2 border-violet-100 gap-2">
      <div className="font-semibold">
        <div>{city + ", " + state}</div>
      </div>
      <div>
        <div className="font-bold text-xl">{firstName + " " + lastName}</div>
        <div className="font-semibold">User Id:{id}</div>
        {party === "Democrat" ? (
          <div className="badge bg-blue-200">{party}</div>
        ) : party === "Republican" ? (
          <div className="badge bg-red-200">{party}</div>
        ) : (
          <div className="badge bg-gray-200">{party || "Independent"}</div>
        )}
        {position && (
          <div className="font-semibold">
            Running for: {(position.at(0)?.toUpperCase() + position.slice(1))}
          </div>
        )}
        <div className="font-semibold">
          {rating == -1
            ? "Not Rated"
            : `Approval Rating: ${(rating * 100).toFixed(2)}%`}
        </div>
      </div>
      <div className="flex items-center justify-center">
        <img
          src={picture || `https://i.pravatar.cc/150?img=${id}`}
          alt="avatar"
          className="rounded-lg w-28 md:w-36 lg:w-44"
        />
      </div>
    </div>
  )
}

export async function action({ request }: ActionFunctionArgs) {
  const data = await request.formData()
  const searchQuery = data.get("search-query")?.toString()
  const searchFilter = data.get("search-filter")?.toString()
  if (!searchQuery || !searchFilter) {
    return null
  }

  try {
    const users = await getSearchedUsers(searchQuery, searchFilter)

    if (!users) {
      return redirect("/error")
    }

    const usersWithRating = await Promise.all(
      users.map(async (user) => {
        const rating = await getTotalRating(user.id)
        console.log(rating)
        return { ...user, rating }
      })
    )
    console.log(usersWithRating)

    return usersWithRating
  } catch (error) {
    console.error(error)
    return redirect("/error")
  }
}
