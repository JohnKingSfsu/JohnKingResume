import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node"
import { Link, useLoaderData, useOutletContext } from "@remix-run/react"
import { User } from "backend/models/user"
import { authenticator } from "backend/services/auth/auth"
import { Handshake } from "lucide-react"
import { useEffect } from "react"
import { ContextType } from "~/types"

export const meta: MetaFunction = () => {
  return [
    { title: "CSC648 Voting App" },
    {
      name: "description",
      content: "This application is for demonstration purposes only.",
    },
  ]
}

export async function loader({ request }: LoaderFunctionArgs) {
  const user = await authenticator.isAuthenticated(request)
  return user
}

export default function Index() {
  const user = useLoaderData<User>()
  const { handleTitleChange } = useOutletContext<ContextType>()
  useEffect(() => {
    handleTitleChange("")
  }, [handleTitleChange])

  return (
    <div className="h-full flex flex-col items-center justify-center gap-2">
      <h1 className="text-7xl font-bold text-violet-500 md:text-9xl">
        PoliticalQ
      </h1>
      <h2 className="text-2xl font-semibold md:text-4xl">Empowering Voters</h2>
      <div className="pt-8">
        <Link to={user ? "/login" : "/dashboard"} className="btn">
          {user ? "View your profile!" : "Join the conversation!"}
        </Link>
      </div>
    </div>
  )
}
