import { LoaderFunctionArgs, redirect } from "@remix-run/node"
import { Link, useLoaderData, useParams } from "@remix-run/react"
import { getVotesByUser } from "backend/models/vote.ts"
import { authenticator } from "backend/services/auth/auth"


export async function loader({ request, params }: LoaderFunctionArgs) {
  const user = await authenticator.isAuthenticated(request, {
    failureRedirect: "/login",
  })

  const { id } = params
  if (isNaN(id)) {
    redirect("/error")
  }

  const votes = await getVotesByUser(user.id.toString())


  return votes || redirect("/error")
}

export default function History() {
  const data = useLoaderData<typeof loader>()
  const votes = data.map((info) => {
    return {
      election: info.elections.title,
      politician: info.users.firstName + " " + info.users.lastName,
    }
    console.log(info)
  })

  return (
    <div className="flex flex-col items-center">
      <h1 className="text-4xl font-bold">Voting History</h1>
      {votes.map((vote) => (
        <HistoryCard key={vote.id} {...vote} />
      ))}
    </div>
  )
}

type HistoryCardProps = {
  politician: string
  election: string
}

function HistoryCard({ politician, election }: HistoryCardProps) {
  return (
    <div className="w-full md:w-1/2 p-4">
      <div className="card shadow-md border-purple-200 border">
        <div className="card-body">
          <h2 className="card-title">{election}</h2>
          <div className="card-subtitle text-gray-500">
            <p>Politician voted for: {politician}</p>
          </div>
        </div>
      </div>
    </div>
  )
}
