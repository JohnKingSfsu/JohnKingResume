import { LoaderFunctionArgs, redirect } from "@remix-run/node"
import { Link, useLoaderData } from "@remix-run/react"
import { getElections } from "backend/models/election"
import { authenticator } from "backend/services/auth/auth"

export async function loader({ request }: LoaderFunctionArgs) {
  const user = await authenticator.isAuthenticated(request, {
    failureRedirect: "/login",
  })

  const elections = await getElections()

  return elections || redirect("/error")
}

export default function Elections() {
  const data = useLoaderData<typeof loader>()
  const elections = data.map((info) => {
    return {
      id: info.id,
      name: info.title,
      type: info.type.charAt(0).toUpperCase() + info.type.slice(1),
      startDate: new Date(info.startDate).toLocaleDateString(),
      status: getElectionStatus(
        new Date(info.startDate),
        new Date(info.endDate)
      ),
    }
  })

  return (
    <div className="flex flex-col items-center">
      <h1 className="text-4xl font-bold">Elections</h1>
      {elections.map((election) => (
        <ElectionCard key={election.id} {...election} />
      ))}
    </div>
  )
}

function getElectionStatus(startDate: Date, endDate: Date) {
  const currentDate = new Date()
  if (currentDate < startDate) {
    return "Upcoming"
  } else if (currentDate > endDate) {
    return "Completed"
  } else {
    return "Active"
  }
}

type ElectionCardProps = {
  id: number
  name: string
  type: string
  startDate: string
  status: string
}

function ElectionCard({
  id,
  name,
  type,
  startDate,
  status,
}: ElectionCardProps) {
  return (
    <div className="w-full md:w-1/2 p-4">
      <div className="card shadow-md border-purple-200 border">
        <div className="card-body">
          <h2 className="card-title">
            {name}
            {status === "Active" ? (
              <div className="badge badge-lg bg-green-200">{status}</div>
            ) : status === "Upcoming" ? (
              <div className="badge badge-lg bg-purple-200">{status}</div>
            ) : (
              <div className="badge badge-lg bg-red-200">{status}</div>
            )}
          </h2>
          <div className="card-subtitle text-gray-500">
            <p>{type}</p>
            <p>Start Date: {startDate}</p>
          </div>
          <div className="card-actions">
            <Link to={`/voting/${id}`} className="btn">
              View Election
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
