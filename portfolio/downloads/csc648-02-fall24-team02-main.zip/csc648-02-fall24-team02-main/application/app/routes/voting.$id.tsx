import {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  redirect,
} from "@remix-run/node"
import { Form, useLoaderData } from "@remix-run/react"
import { getElectionWithCandidates } from "backend/models/election"
import { createVote, getVoteByUser, getVotesByUser } from "backend/models/vote"
import { authenticator } from "backend/services/auth/auth"

export async function loader({ request, params }: LoaderFunctionArgs) {
  const user = await authenticator.isAuthenticated(request, {
    failureRedirect: "/login",
  })

  const id = Number(params.id)
  if (isNaN(id)) {
    redirect("/error")
  }

  // used in Production, we will use the model directly in Development

  // try {
  //   const result = await fetch("api/elections/{id}")
  //   const data: ElectionWithCandidates = await result.json()
  //   return data
  // } catch (error) {
  //   console.error(error)
  //   redirect("/error")
  // }

  try {
    const data = await getElectionWithCandidates(id)
    if (!data) {
      redirect("/error")
    }
    console.log(data)
    return { data, user, electionId: id }
  } catch (error) {
    console.error(error)
    redirect("/error")
  }
}

export default function Voting() {
  const { data, user, electionId } = useLoaderData<typeof loader>()
  const electionTitle = data?.title
  const candidates = data?.candidates || []

  return (
    <div className="h-full w-full flex flex-col items-center gap-2 p-2">
      <h1 className="text-2xl sm:text-4xl font-semibold text-wrap">
        {electionTitle}
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {candidates.map((candidate) => (
          <CandidateCard
            key={candidate.candidateId}
            userId={user.id}
            electionId={electionId}
            {...candidate}
          />
        ))}
      </div>
    </div>
  )
}

type CandidateProps = {
  userId: number
  electionId: number
  candidateId: number
  name: string
  party: string | null
  position: string
  picture: string | null
}

function CandidateCard({
  userId,
  electionId,
  candidateId,
  name,
  party,
  position,
  picture,
}: CandidateProps) {
  return (
    <div className="w-full md:w-96">
      <div className="card shadow-md border-purple-200 border">
        <div className="card-body items-center">
          <h2 className="card-title">{name}</h2>
          <img
            className="rounded-md max-h-80"
            src={
              picture ||
              "https://cdn.donmai.us/360x360/f3/2a/f32af9d3fe6f166fc4b138531c146503.jpg"
            }
            alt={name}
          />
          <div className="card-subtitle text-gray-500 mt-5">
            <p
              className={
                party === "Democrat"
                  ? "text-blue-400"
                  : party === "Republican"
                  ? "text-red-400"
                  : "text-neutral"
              }
            >
              {party ? party : "Independent"}
            </p>
            <p>Position: {position}</p>
            <p className="h-28 overflow-scroll overflow-x-hidden text-wrap">
              {name} is a dedicated and hardworking individual who is passionate
              about becoming a politician.
            </p>
          </div>
          <div className="card-actions flex justify-center">
            <Form method="post">
              <input type="hidden" name="candidate-id" value={candidateId} />
              <input type="hidden" name="election-id" value={electionId} />
              <input type="hidden" name="user-id" value={userId} />
              <button type="submit" className="btn">
                Vote Candidate
              </button>
            </Form>
          </div>
        </div>
      </div>
    </div>
  )
}

export async function action({ request }: ActionFunctionArgs) {
  try {
    const data = await request.formData()
    const voteData = {
      politicianId: Number(data.get("candidate-id")),
      electionId: Number(data.get("election-id")),
      userId: Number(data.get("user-id")),
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    try {
      await createVote(voteData)
    } catch (error) {
      if (error instanceof Error && error.message === "Already Voted") {
      return redirect("/voted-already")
      }
      throw error
    }
    return redirect("/vote-success")
  } catch (error) {
    console.error(error)
    return redirect("/error")
  }
}
