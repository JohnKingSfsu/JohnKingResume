import { Link, useOutletContext } from "@remix-run/react"
import { Divide } from "lucide-react"
import { useEffect } from "react"
import { ContextType } from "~/types"

export default function Votermap() {
  return (
    <div className="h-full flex flex-col md:flex-row">
      {/* Wrapper for content */}
      <div className="flex-1 mr-5 ml-20">
        <p className="text-4xl font-bold text-center mb-8 text-gray-800">
          How do I vote?
        </p>
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d50492.956857073776!2d-122.52114016587029!3d37.724142031226826!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e6!4m5!1s0x808f7db005c0e281%3A0xa57a7c9f946a45d3!2sSan%20Francisco%20State%20University%2C%20Holloway%20Avenue%2C%20San%20Francisco%2C%20CA!3m2!1d37.7241492!2d-122.4799405!4m5!1s0x808f7db005c0e281%3A0xa57a7c9f946a45d3!2sSan%20Francisco%20State%20University%2C%20Holloway%20Avenue%2C%20San%20Francisco%2C%20CA!3m2!1d37.7241492!2d-122.4799405!5e0!3m2!1sen!2sus!4v1730246298862!5m2!1sen!2sus"
          width="300"
          height="400"
          loading="lazy"
          className="my-5 sm:hidden block"
        ></iframe>
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d50492.956857073776!2d-122.52114016587029!3d37.724142031226826!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e6!4m5!1s0x808f7db005c0e281%3A0xa57a7c9f946a45d3!2sSan%20Francisco%20State%20University%2C%20Holloway%20Avenue%2C%20San%20Francisco%2C%20CA!3m2!1d37.7241492!2d-122.4799405!4m5!1s0x808f7db005c0e281%3A0xa57a7c9f946a45d3!2sSan%20Francisco%20State%20University%2C%20Holloway%20Avenue%2C%20San%20Francisco%2C%20CA!3m2!1d37.7241492!2d-122.4799405!5e0!3m2!1sen!2sus!4v1730246298862!5m2!1sen!2sus"
          width="500"
          height="500"
          loading="lazy"
          className="my-5 sm:block hidden"
        ></iframe>
      </div>

      {/* Text (right side) */}
      <div className="flex-1 ml-10 text-lg m-4">
        <p className="leading-relaxed">
          These are the locations that you can vote at in your city for the
          election.
        </p>
        <br />
        <p>Here's how you can vote:</p>
        <ol className="list-decimal pl-5">
          <li>Make sure you're a citizen</li>
          <li>Register to vote with your state!</li>
        </ol>

        {/* Collapsible sections */}
        <div className="mt-5">
          <div className="collapse collapse-arrow bg-white border-2 border-black shadow-sm">
            <input type="checkbox" name="peer hidden" defaultChecked />
            <div className="collapse-title text-xl font-medium">
              Am I eligible to vote?
            </div>
            <div className="collapse-content">
              <p>
                Check if you meet the age, citizenship, and residency
                requirements to vote in your area.
              </p>
            </div>
          </div>
          <div className="collapse collapse-arrow bg-white border-2 border-black shadow-sm">
            <input type="checkbox" name="peer hidden" />
            <div className="collapse-title text-xl font-medium">
              Can I register to vote online?
            </div>
            <div className="collapse-content">
              <p>
                Learn about online voter registration options and find the right
                website for your state.
              </p>
            </div>
          </div>
          <div className="collapse collapse-arrow bg-white border-2 border-black shadow-sm">
            <input type="checkbox" name="peer hidden" />
            <div className="collapse-title text-xl font-medium">
              Are there language assistance options available?
            </div>
            <div className="collapse-content">
              <p>
                Check if your polling location provides ballots or help in other
                languages.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
