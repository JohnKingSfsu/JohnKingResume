import {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  redirect,
} from "@remix-run/node"
import { Form } from "@remix-run/react"
import { authenticator } from "backend/services/auth/auth"
import { insertPolitician } from "backend/models/politician"

export async function loader({ request }: LoaderFunctionArgs) {
  const user = await authenticator.isAuthenticated(request)
  if (!user || user.userRole !== "admin") {
    return redirect("/error")
  }

  return user
}

export default function CreatePolitician() {
  return (
    <Form
      method="post"
      className="flex flex-col gap-4 p-4 bg-purple-50 rounded m-5"
    >
      <div className="flex flex-col w-1/2">
      <label className="font-semibold text-xl pb-2">First Name</label>
      <input type="text" name="firstName" className="h-10 rounded-md p-2" />
      </div>
      <div className="flex flex-col w-1/2">
      <label className="font-semibold text-xl pb-2">Last Name</label>
      <input type="text" name="lastName" className="h-10 rounded-md p-2" />
      </div>
      <div className="flex flex-col w-1/2">
      <label className="font-semibold text-xl pb-2">Party</label>
      <select name="party" className="h-10 rounded-md p-2">
        <option value="Republican">Republican</option>
        <option value="Democrat">Democrat</option>
        <option value="Independent">Independent</option>
      </select>
      </div>
      <div className="flex flex-col w-1/2">
      <label className="font-semibold text-xl pb-2">City</label>
      <input type="text" name="city" className="h-10 rounded-md p-2" />
      </div>
      <div className="flex flex-col w-1/2">
      <label className="font-semibold text-xl pb-2">State</label>
      <input type="text" name="state" className="h-10 rounded-md p-2" />
      </div>
      <div className="flex flex-col w-1/2">
      <label className="font-semibold text-xl pb-2">Position</label>
      <select name="position" className="h-10 rounded-md p-2">
        <option value="president">President</option>
        <option value="senator">Senator</option>
        <option value="representative">Representative</option>
        <option value="governor">Governor</option>
        <option value="mayor">Mayor</option>
      </select>
      </div>
      <button type="submit" className="btn w-1/2 bg-pink-100">
      Create Politician
      </button>
    </Form>
  )
}

export async function action({ request }: ActionFunctionArgs) {
  const formData = await request.formData()
  const firstName = formData.get("firstName") as string
  const lastName = formData.get("lastName") as string
  const party = formData.get("party") as string
  const city = formData.get("city") as string
  const state = formData.get("state") as string
  const position = formData.get("position") as
    | "president"
    | "senator"
    | "representative"
    | "governor"
    | "mayor"

  try {
    await insertPolitician(
      {
        firstName,
        lastName,
        party,
      },
      position,
      city,
      state
    )
  } catch (error) {
    return redirect("/error")
  }

  return redirect("/admin")
}
