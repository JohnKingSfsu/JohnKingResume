import { Link, useOutletContext } from "@remix-run/react"
import { useEffect } from "react"
import { ContextType } from "~/types"

export default function About() {
  const teamMembers = [
    {
      name: "Jia Yang",
      role: "Team Lead",
      bio: "Jia is a senior at SFSU majoring in Computer Science.",
      profile: "/jia",
    },
    {
      name: "Jisel Rivera",
      role: "Frontend Lead",
      bio: "Jisel is a senior at SFSU majoring in Computer Science.",
      profile: "/jisel",
    },
    {
      name: "Kaitlyn Yip",
      role: "Frontend Engineer",
      bio: "Kaitlyn is a senior at SFSU majoring in Computer Science.",
      profile: "/kaitlyn",
    },
    {
      name: "John King",
      role: "Database Engineer",
      bio: "John is a senior at SFSU majoring in Computer Science.",
      profile: "/john",
    },
    {
      name: "Joshua Francisco",
      role: "Backend Engineer",
      bio: "Josh is a senior at SFSU majoring in Computer Science.",
      profile: "/josh",
    },
    {
      name: "Steven Brandt",
      role: "Backend Developer",
      bio: "Steven is a senior at SFSU majoring in Computer Science.",
      profile: "/steven",
    },
    
    {
      name: "Eduardo Rodriguez",
      role: "Backend Lead",
      bio: "Eduardo is a senior at SFSU majoring in Computer Science.",
      profile: "/eduardo",
    },
  ]

  return (
    <div className="flex flex-col w-full items-center">
      <h1 className="text-4xl font-bold p-5">About Us</h1>
      <div className="h-full w-screen flex flex-wrap justify-center">
        {teamMembers.map((member) => (
          <MemberCard key={member.name} {...member} />
        ))}
      </div>
    </div>
  )
}

type MemberCardProps = {
  name: string
  role: string
  bio: string
  profile: string
}

function MemberCard({ name, role, bio, profile }: MemberCardProps) {
  return (
    <div className="w-2/3 p-2">
      <div className="card shadow-md border-purple-200 border-2">
        <div className="card-body">
          <h2 className="card-title">{name}</h2>
          <div className="card-subtitle text-gray-500">
            <p>Role: {role}</p>
          </div>
          <p className="h-24 overflow-hidden">{bio}</p>
          <div className="card-actions">
            <Link to={profile} className="btn">
              View Profile
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
