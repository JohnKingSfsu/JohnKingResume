import React, { useState, useEffect } from "react";
import ReactMarkdown from "react-markdown";

type Message = {
  sender: "user" | "bot";
  text: string;
};

export default function ChatbotPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState<string>("");
  const [isStreaming, setIsStreaming] = useState<boolean>(false);

  // Initial bot message when page loads
  useEffect(() => {
    setMessages([
      {
        sender: "bot",
        text: "Hello there, I am an AI assistant made to help answer questions on political topics! How may I help you?",
      },
    ]);
  }, []);

  // Sends a message to the chatbot backend
  const sendMessage = async () => {
    if (!input.trim()) return;

    // Log the user's message
    setMessages((prev) => [...prev, { sender: "user", text: input }]);

    const userMessage = input;
    setInput("");

    try {
      const response = await fetch("/chatbot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMessage }),
      });

      if (!response.ok) {
        throw new Error("Failed to fetch response from chatbot.");
      }

      const data = await response.json();

      // Add the bot's response to the conversation log
      setMessages((prev) => [
        ...prev,
        { sender: "bot", text: data.reply || "I'm here to help!" },
      ]);
    } catch (error) {
      console.error("Error fetching chatbot response:", error);
      setMessages((prev) => [
        ...prev,
        { sender: "bot", text: "Sorry, something went wrong." },
      ]);
    }
  };

  // Sends message and handles streaming responses
  const sendStreamingMessage = async () => {
    if (!input.trim()) return;

    // Log user's message
    setMessages((prev) => [...prev, { sender: "user", text: input }]);

    const userMessage = input;
    setInput("");
    setIsStreaming(true);

    try {
      const response = await fetch("/chatbot/stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMessage }),
      });

      if (!response.ok || !response.body) {
        throw new Error("Failed to fetch response from chatbot.");
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let botMessage = "";

      // Process streaming chunks
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        botMessage += decoder.decode(value);

        // Update the last bot message
        setMessages((prev) => {
          const lastMessage = prev[prev.length - 1];
          if (lastMessage?.sender === "bot") {
            return [...prev.slice(0, -1), { sender: "bot", text: botMessage }];
          } else {
            return [...prev, { sender: "bot", text: botMessage }];
          }
        });
      }
    } catch (error) {
      console.error("Error fetching chatbot response:", error);
      setMessages((prev) => [
        ...prev,
        { sender: "bot", text: "Sorry, something went wrong." },
      ]);
    } finally {
      setIsStreaming(false);
    }
  };

  return (
    <div className="chatbot-page-container flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <h1 className="text-3xl font-bold mb-6">AI Political Assistant</h1>
      <div className="chat-container w-full max-w-2xl bg-white shadow-md rounded-lg p-4 flex flex-col space-y-4">
        {/* Conversation Log */}
        <div className="conversation-log flex-1 overflow-y-auto border border-gray-300 rounded-lg p-4 bg-gray-50 space-y-4">
          {messages.map((msg, index) => (
            <div
              key={index}
              className={`message ${
                msg.sender === "user" ? "text-right" : "text-left"
              }`}
            >
              {msg.sender === "bot" ? (
                <ReactMarkdown className="inline-block rounded-lg px-4 py-2 bg-gray-200 text-black">
                  {msg.text}
                </ReactMarkdown>
              ) : (
                <p className="inline-block rounded-lg px-4 py-2 bg-violet-500 text-white">
                  {msg.text}
                </p>
              )}
            </div>
          ))}
          {isStreaming && (
            <div className="message text-left">
              <p className="inline-block rounded-lg px-4 py-2 bg-gray-200 text-black">
                Typing...
              </p>
            </div>
          )}
        </div>

        {/* User Input */}
        <div className="input-container flex items-center space-x-4">
          <input
            type="text"
            className="input flex-1 border border-gray-300 rounded-lg px-4 py-2 focus:outline-none"
            placeholder="Type your political question..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendStreamingMessage()}
          />
          <button
            className="btn bg-violet-500 text-white px-6 py-2 rounded-lg hover:bg-violet-500"
            onClick={sendStreamingMessage}
            disabled={isStreaming}
          >
            {isStreaming ? "Typing..." : "Send"}
          </button>
        </div>
      </div>
    </div>
  );
}

