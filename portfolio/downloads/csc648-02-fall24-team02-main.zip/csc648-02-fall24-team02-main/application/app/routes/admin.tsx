import { useNavigate } from "react-router-dom"
import { UserRound } from "lucide-react"
import { Scale } from "lucide-react"
import { Link } from "@remix-run/react"
import { authenticator } from "backend/services/auth/auth"
import { LoaderFunctionArgs, redirect } from "@remix-run/node"

export async function loader({ request }: LoaderFunctionArgs) {
  const user = await authenticator.isAuthenticated(request, {
    failureRedirect: "/login",
  })
  // if (user.userRole !== "admin") {
  //   return redirect("/error")
  // }
  return {}
}
const AdminDashboard = () => {
  return (
    <div className="flex flex-col items-center p-8">
      <div className="bg-white shadow-xl rounded-lg p-8 w-full max-w-3xl">
        <h1 className="text-4xl font-bold text-center mb-8 text-gray-800">
          Admin Dashboard
        </h1>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
          <Link to="/create-politician" className="flex flex-col items-center bg-white  rounded-lg p-6 transition transform hover:-translate-y-1 hover:shadow-xl cursor-pointer">
            {" "}
            {/* Manage Users */}
            <UserRound size={48} color="black" className="mb-4" />
            <div>Create Politician</div>
          </Link>
          <Link to="/create-election" className="flex flex-col items-center bg-white  rounded-lg p-6 transition transform hover:-translate-y-1 hover:shadow-xl cursor-pointer">
            {" "}
            {/* add candidate */}
            <Scale size={48} color="black" className="mb-4" />
            <div>Create Election</div>
          </Link>
        </div>
      </div>
    </div>
  )
}

export default AdminDashboard
