import React from 'react';

export default function Info() {
  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1>Jisel Rivera</h1>
      <p>My name is Jisel Rivera, and I'm a senior at San Francisco State University (SFSU).</p>
    </div>
  );
}