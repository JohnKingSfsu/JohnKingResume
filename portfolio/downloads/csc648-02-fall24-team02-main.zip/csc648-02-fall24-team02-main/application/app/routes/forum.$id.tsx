import { ActionFunctionArgs,LoaderFunctionArgs, redirect } from "@remix-run/node"

import React, { useEffect, useState } from "react"
import { Form, Link, useParams, useLoaderData } from "@remix-run/react"
import { authenticator } from "backend/services/auth/auth"
import { insertComment } from "backend/models/comments"

export async function loader({ request, params }: LoaderFunctionArgs) {
  const user = await authenticator.isAuthenticated(request, {
    failureRedirect: "/error",
  })

  const { id } = params; // Directly use params from LoaderFunctionArgs

  // Ensure both are strings for comparison
  if (user.id.toString() !== id) {
    return redirect("/login");
  }

  return{user,id}
}

function Posts() {
  const [results, setResults] = useState([])
  const { id } = useParams()
  

  useEffect(() => {
    // Fetch posts with comments
    const fetchPosts = async () => {
      const response = await fetch("/posts/retrieval")
      if (!response.ok) {
        throw new Error("Failed to fetch posts.")
      }
      const data = await response.json()

      console.log("info from data:", data)
      setResults(data)
    }

    fetchPosts()
  }, [])

  return (
    <div className="container mx-auto px-4 py-6">
    {/* Page Header */}
    <div className="flex justify-between items-center mb-6">
      <h1 className="text-3xl font-bold">Forum</h1>
      <Link
        to={`/createPost/${id}`}
        className="px-4 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-500"
      >
        Make Your Own Post
      </Link>
    </div>

    {/* Post List */}
    <ul className="space-y-4">
      {results.map(({ post, comments }: any) => (
        <li
          key={post.id}
          className="bg-white shadow border border-gray-200 rounded-lg p-6"
        >
          {/* Post Content */}
          <div className="mb-4">
            <h2 className="text-xl font-bold mb-2">{post.postText}</h2>
            <p className="text-sm text-gray-600">
              Posted by{" "}
              <span className="font-medium">
                {post.authorFirstName} {post.authorLastName}
              </span>
            </p>
          </div>

          {/* Comments Section */}
          <div className="mb-4">
            <h3 className="text-lg font-semibold">Comments:</h3>
            {comments && comments.length > 0 ? (
              <ul className="space-y-3 mt-2">
                {comments.map((comment: any, index: number) => (
                  <li key={index} className="border p-3 rounded-lg">
                    <p>{comment.commentText}</p>
                    <p className="text-sm text-gray-500">
                      By: <span className="font-medium">{comment.authorUsername}</span> on{" "}
                      {new Date(comment.commentCreatedAt).toLocaleString()}
                    </p>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-gray-500">No comments available.</p>
            )}
          </div>

          {/* Comment Form */}
          <Form method="post" className="space-y-3">
            <input type="hidden" name="postId" value={post.postId} />
            <textarea
              name="commentText"
              placeholder="Write your comment here..."
              className="w-full border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring focus:border-blue-300"
              required
            />
            <button
              type="submit"
              className="px-4 py-2 bg-green-600 text-white rounded-lg shadow hover:bg-green-500"
            >
              Reply
            </button>
          </Form>
        </li>
      ))}
    </ul>

    {/* No Posts Fallback */}
    {results.length === 0 && (
      <p className="text-center text-gray-500 mt-10">No posts available. Be the first to post!</p>
    )}
  </div>
)
}

export async function action({ request, params }: ActionFunctionArgs) {
  try {
    const data = await request.formData()
    console.log(data)
    console.log(params.id)

    const commentData = {
      id: Number(null),
      postsId: Number(data.get("postId")),
      commenterId: Number(params.id),
      text: data.get("commentText")?.toString() || "",
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    const response = await insertComment(commentData)

    return redirect(`/forum/${params.id}`, {
      headers: { "Cache-Control": "no-cache" }, // Ensure fresh data is loaded
    })
  } catch (error) {
    console.error(error)
    return redirect("/error")
  }
}

export default Posts
