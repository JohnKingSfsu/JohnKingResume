import { useLoaderData } from "@remix-run/react"
import { json } from "@remix-run/node"

type CatImage = {
  id: string
  url: string
  width: number
  height: number
}

export async function loader() {
  try {
    const res = await fetch("https://api.thecatapi.com/v1/images/search")
    return json(await res.json())
  } catch (error) {
    console.error(error)
  }
}
export default function Info() {
  const catImage = useLoaderData<typeof loader>()[0]
  console.log(catImage.url)

  return (
    <div className="flex flex-col align-middle">
      <h1 className="text-3xl text-blue-400">Jia Yang</h1>
      <p>My name is Jia Yang, a senior at SFSU.</p>
      <p>Here is a cat image:</p>
      <img src={catImage.url} width={catImage.width} height={catImage.height} alt="cat" />
    </div>
  )
}
