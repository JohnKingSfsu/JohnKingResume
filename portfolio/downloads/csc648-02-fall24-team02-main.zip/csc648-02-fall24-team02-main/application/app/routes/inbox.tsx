import { LoaderFunctionArgs, redirect } from "@remix-run/node"
import { Form, useLoaderData } from "@remix-run/react"
import { getMessages, insertMessage } from "backend/models/message"
import { getUser } from "backend/models/user"
import { authenticator } from "backend/services/auth/auth"
import { PenLine } from "lucide-react"
import { useState } from "react"

type Email = {
  id: number
  senderId: number
  name: string
  subject: string
  message: string
  response: string
}

export async function loader({ request }: LoaderFunctionArgs) {
  const user = await authenticator.isAuthenticated(request)
  if (!user) {
    return redirect("/login")
  }

  const messages = await getMessages(user.id)
  if (!messages) {
    return { emails: [] } as { emails: Email[] }
  }

  const emails = await Promise.all(
    messages.map(async (message) => {
      const sender = await getUser(message.senderId)
      return {
        id: message.id,
        senderId: message.senderId,
        name: sender?.firstName + " " + sender?.lastName,
        subject: message.subject,
        message: message.text,
        response: "",
      } as Email
    })
  )

  return emails as Email[]
}

const testMsgs: Email[] = [
  {
    id: 1,
    senderId: 1,
    name: "John Doe",
    subject: "Hello",
    message: "Hello, how are you?",
    response: "",
  },
  {
    id: 2,
    senderId: 2,
    name: "Jane Smith",
    subject: "Meeting",
    message: "Can we meet tomorrow?",
    response: "",
  },
]

export default function Inbox() {
  const inboxMsgs = useLoaderData<Email[]>()
  const [emails, setEmails] = useState<Email[]>(inboxMsgs || testMsgs)
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null)
  const [response, setResponse] = useState<string>("")

  const handleSelectEmail = (email: Email) => {
    setSelectedEmail(email)
    setResponse(email.response || "")
  }

  return (
    <div className="flex flex-col h-full lg:flex-row p-4 sm:p-6 lg:p-8">
      {/* Email List */}
      <div className="bg-white shadow-md rounded-lg p-4 w-full lg:w-1/3 mb-4 lg:mb-0">
        <div className="flex justify-between">
          <h2 className="text-xl font-semibold mb-4">Inbox</h2>
          <button onClick={() => setSelectedEmail(null)}>
            <PenLine />
          </button>
        </div>
        <ul className="space-y-2">
          {emails.map((email) => (
            <li
              key={email.id}
              className="p-3 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100"
              onClick={() => handleSelectEmail(email)}
            >
              <p className="font-bold">{email.subject}</p>
              <p className="text-gray-600 text-sm">{email.name}</p>
            </li>
          ))}
        </ul>
      </div>
      {/*Response Section */}
      <div className="bg-white shadow-md rounded-lg p-4 w-full lg:w-2/3">
        {selectedEmail ? (
          <Form method="post">
        <h2 className="text-xl font-semibold mb-2">Email Details</h2>
        <div className="mb-4">
          <p>
            <span className="font-bold">From:</span> {selectedEmail.name}
          </p>
          <p>
            <span className="font-bold">Subject:</span>{" "}
            {selectedEmail.subject}
          </p>
          <p>
            <span className="font-bold">Message:</span>{" "}
            {selectedEmail.message}
          </p>
        </div>
        <div className="form-control mb-4">
          <input type="hidden" name="userId" value={selectedEmail.senderId} />
          <label className="label">
            <span className="label-text">Subject</span>
          </label>
          <input
            type="text"
            name="subject"
            className="input input-bordered w-full"
            defaultValue={'Re: '}
            required
          />
          <label className="label">
            <span className="label-text">Message</span>
          </label>
          <textarea
            name="message"
            placeholder="Type your response here"
            className="textarea textarea-bordered w-full"
            value={response}
            onChange={(e) => setResponse(e.target.value)}
            required
          ></textarea>
        </div>
        <div className="form-control mt-6">
          <button type="submit" className="btn btn-primary w-full">
            Send Response
          </button>
        </div>
          </Form>
        ) : (
          <Form method="post" className="h-full">
            <p className="text-center text-gray-600 font-semibold">
              Send a message
            </p>
            <div className="form-control mb-4">
              <label className="label">
                <span className="label-text">Message Subject</span>
              </label>
              <input
                type="text"
                name="subject"
                className="input input-bordered w-full"
                required
              />

              <label className="label">
                <span className="label-text">Send to user id</span>
              </label>
              <input
                type="number"
                name="userId"
                className="input input-bordered w-full"
                required
              />

              <label className="label">
                <span className="label-text">Message Contents</span>
              </label>
              <textarea
                name="message"
                placeholder="Type your message here"
                className="textarea textarea-bordered w-full h-32"
                required
              ></textarea>

              <button className="btn btn-primary w-full mt-2" type="submit">
                Send Message
              </button>
            </div>
          </Form>
        )}
      </div>
    </div>
  )
}

export async function action({ request }: LoaderFunctionArgs) {
  const user = await authenticator.isAuthenticated(request)
  if (!user) {
    return redirect("/login")
  }
  console.log("user id is:", user.id)

  const formData = await request.formData()
  const messageId = formData.get("messageId")

  const subject = formData.get("subject") as string
  const userId = formData.get("userId") as string
  const message = formData.get("message") as string

  const messageData = {
    senderId: user.id,
    receiverId: Number(userId),
    subject,
    text: message,
    createdAt: new Date(),
    updatedAt: new Date(),
  }

  console.log('Message data:', messageData)

  try {
    await insertMessage(messageData)
  } catch (error) {
    return redirect("/error")
  }

  return redirect("/inbox")
}
