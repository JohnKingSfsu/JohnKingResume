import { Link } from "@remix-run/react";

export default function Error() {
  return (
    <div className="h-full w-full flex flex-col justify-center items-center p-4 gap-4">
      <div className="w-1/2 flex flex-col gap-2">
        <h1 className="text-6xl text-violet-500 font-bold">Error</h1>
        <h2 className="text-2xl text-pink-400 font-semibold">
          Oops, this is embarrassing.
        </h2>
        <p className="text-lg">
          Sorry, something went wrong with the application. Try again later.
        </p>
      </div>
    </div>
  )
}
