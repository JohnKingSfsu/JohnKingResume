import { useState, useEffect } from "react";
import { useOutletContext } from "@remix-run/react";
import { ContextType } from "~/types";

export default function Intro() {
  const { handleTitleChange } = useOutletContext<ContextType>();

  // State to track which accordion is open
  const [openAccordion, setOpenAccordion] = useState<string | null>(null);

  return (
    <div className="m-4">
      <p className="text-4xl font-bold text-center mb-8 text-gray-800">Political Parties</p>
      <div className="space-y-4">
        <div className="collapse collapse-arrow bg-blue-100 border-2 border-blue-300 shadow-lg rounded-lg transition-all">
          <input type="checkbox" name="peer hidden" defaultChecked />
          <div className="collapse-title text-2xl font-semibold text-blue-800 hover:text-blue-600 transition-colors">
            Democratic Party
          </div>
          <div className="collapse-content text-gray-700 p-4">
            <p>The Democratic Party is one of the two major political parties in the United States. Historically, it has been associated with progressive and liberal ideologies, advocating for social equality, environmental protection, healthcare reform, and a more robust role for the government in regulating the economy and providing social services. Democrats generally support policies that promote civil rights, labor rights, and broader access to education and healthcare.</p>
          </div>
        </div>
        <div className="collapse collapse-arrow bg-red-100 border-2 border-red-300 shadow-lg rounded-lg transition-all">
          <input type="checkbox" name="peer hidden" />
          <div className="collapse-title text-2xl font-semibold text-red-800 hover:text-red-600 transition-colors">
            Republican Party
          </div>
          <div className="collapse-content text-gray-700 p-4">
            <p>The Republican Party is the other major political party in the United States, often associated with conservative and right-leaning ideologies. Republicans tend to favor limited government intervention in the economy, lower taxes, individual liberties, and a free-market approach. They advocate for a strong national defense, traditional values, and policies that support business and entrepreneurship. Republicans are generally more skeptical of government regulation and tend to prioritize national security and reducing the size of the federal government.</p>
          </div>
        </div>
        <div className="collapse collapse-arrow bg-green-100 border-2 border-green-300 shadow-lg rounded-lg transition-all">
          <input type="checkbox" name="peer hidden" />
          <div className="collapse-title text-2xl font-semibold text-green-800 hover:text-green-600 transition-colors">
            Green Party
          </div>
          <div className="collapse-content text-gray-700 p-4">
            <p>The Green Party is a political party in the United States that emphasizes environmentalism, social justice, and progressive policies. It seeks to address issues such as climate change, wealth inequality, and the concentration of power in corporations and government. The party advocates for creating a more sustainable, equitable society through systemic change.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
