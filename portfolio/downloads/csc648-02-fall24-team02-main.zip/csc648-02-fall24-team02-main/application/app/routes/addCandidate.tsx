import React, { useState } from "react";

const AddCandidate: React.FC = () => {
  const [candidate, setCandidate] = useState({
    name: "",
    email: "",
    party: "",
  });

  const [successMessage, setSuccessMessage] = useState("");

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setCandidate({ ...candidate, [name]: value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMessage(`${candidate.name} has been successfully added!`);
    setCandidate({ name: "", email: "", party: "" });
  };

  return (
    <div
      style={{
        maxWidth: "600px",
        margin: "50px auto",
        padding: "20px",
        boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
        borderRadius: "8px",
        backgroundColor: "#f9f9f9",
      }}
      
      // heading / form
    > 
      <h2 style={{ textAlign: "center", color: "#333",fontSize: "24px" , marginBottom: "15px" , fontWeight: "bold"}}>Add Candidate</h2>
      {successMessage && (
        <p
          style={{
            textAlign: "center",
            color: "green",
            fontWeight: "bold",
            marginTop: "10px",
          }}
        >
          {successMessage}
        </p>
      )} 
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: "15px" }}>
          <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold" }}>
            Candidate Name:
          </label>
          <input
            type="text"
            name="name"
            value={candidate.name}
            onChange={handleChange}
            style={{
              width: "100%",
              padding: "10px",
              borderRadius: "4px",
              border: "1px solid #ddd",
            }}
            required
          />
        </div>
        <div style={{ marginBottom: "15px" }}>
          <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold" }}>
            Email:
          </label>
          <input
            type="email"
            name="email"
            value={candidate.email}
            onChange={handleChange}
            style={{
              width: "100%",
              padding: "10px",
              borderRadius: "4px",
              border: "1px solid #ddd",
            }}
            required
          />
        </div>
        <div style={{ marginBottom: "15px" }}>
          <label style={{ display: "block", marginBottom: "5px", fontWeight: "bold" }}>
            Political Party:
          </label>
          <select
            name="party"
            value={candidate.party}
            onChange={handleChange}
            style={{
              width: "100%",
              padding: "10px",
              borderRadius: "4px",
              border: "1px solid #ddd",
            }}
            required
          >
            <option value="" disabled>
              Select a party
            </option>
            <option value="Republican">Republican</option>
            <option value="Democrat">Democrat</option>
            <option value="Independent">Independent</option>
          </select>
        </div>
        <button
          type="submit"
          style={{
            width: "100%",
            padding: "10px",
            border: "none",
            borderRadius: "4px",
            backgroundColor: "#007BFF",
            color: "#fff",
            fontWeight: "bold",
            cursor: "pointer",
          }}
        >
          Add Candidate
        </button>
      </form>
    </div>
  );
};

export default AddCandidate;
