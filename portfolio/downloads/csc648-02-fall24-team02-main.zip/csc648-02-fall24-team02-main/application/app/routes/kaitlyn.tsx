export default function Info() {
  return (
    <div>
      <h1>Kaitlyn Yip</h1>
      <p>My name is Kaitlyn Yip and I am a senior at SFSU. Hello</p>
    </div>
  )
}