import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";

// loader function fetches data from PokéAPI
export const loader = async () => {
  const response = await fetch("https://pokeapi.co/api/v2/pokemon/bidoof");
  const data = await response.json();
  return json(data);
};

export default function Info() {
  const pokemon: any = useLoaderData(); // casting pokemon as any doesn't matter here, it's just to get rid of type errors

  // creates string from types list for webpage use
  // @ts-ignore
  const pokemonTypes = pokemon.types.map((typeInfo) => typeInfo.type.name).join(", ");

  return (
    <div>
      <h1>Joshua Francisco</h1>
      <p>
        My name is Josh Francisco. I am a senior at SFSU.
        </p>
      <p>
        My favorite Pokémon is {pokemon.name}. Its Pokédex ID is {pokemon.id} and it is a {pokemonTypes} type.
        </p>
    </div>
  );
}