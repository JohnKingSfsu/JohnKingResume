export default function Info() {
    return (
    <div>
        <h1><strong>John King</strong></h1>
        <h2>Student ID: 920628771</h2>
        <p>
            My name is John King and I am a senior at SFSU
        </p>
    </div>
    )
    }