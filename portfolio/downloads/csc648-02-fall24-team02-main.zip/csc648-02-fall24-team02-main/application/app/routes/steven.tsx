export default function Info(){
    return (
        <div>
          <h1>Steven Brandt</h1>
          <p>My name is Steven Brandt and i'm a senior at SFSU</p>
        </div>
      )
}