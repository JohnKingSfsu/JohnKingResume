import { Link } from "@remix-run/react"

export default function VoteResult() {
  return (
    <div className="h-full w-full flex flex-col items-center justify-center">
      <div className="w-2/3 lg:w-1/3 p-10 bg-slate-100 rounded-lg shadow-md flex flex-col">
        <h1 className="text-4xl font-bold text-violet-400">Vote Result</h1>
        <h3 className="text-xl text-gray-500">Thank you for voting!</h3>
        <p className="text-lg py-4 text-wrap">
          Your vote has been successfully submitted. We will notify you by inbox
          when the results are in.
        </p>
        <div className="flex justify-center p-4">
          <button className="btn shadow-md">
            <Link to="/elections">Back to Elections</Link>
          </button>
        </div>
      </div>
    </div>
  )
}
