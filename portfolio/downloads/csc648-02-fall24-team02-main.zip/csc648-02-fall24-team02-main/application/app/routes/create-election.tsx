import {
  ActionFunction,
  ActionFunctionArgs,
  LoaderFunctionArgs,
  redirect,
} from "@remix-run/node"
import { Form, useLoaderData } from "@remix-run/react"
import { createElection } from "backend/models/election"
import { getPoliticians } from "backend/models/politician"
import { authenticator } from "backend/services/auth/auth"
import { useState } from "react"

export async function loader({ request }: LoaderFunctionArgs) {
  const user = await authenticator.isAuthenticated(request, {
    failureRedirect: "/login",
  })
  if (user.userRole !== "admin") {
    return redirect("/error")
  }
  const politicians = await getPoliticians()
  console.log(politicians)
  return { politicians }
}

export default function CreateElection() {
  const [candidates, setCandidates] = useState<number[]>([1])
  const { politicians } = useLoaderData<typeof loader>()

  const addCandidate = () => {
    setCandidates([...candidates, candidates.length + 1])
  }

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Create New Election</h1>
      <Form method="post" className="space-y-4">
        <div>
          <label className="block">Election Title</label>
          <input
            type="text"
            name="title"
            required
            className="border p-2 w-full"
          />
        </div>
        <div>
          <label className="block">Description</label>
          <textarea name="description" required className="border p-2 w-full" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block">Start Date</label>
            <input
              type="datetime-local"
              name="startDate"
              required
              className="border p-2 w-full"
            />
          </div>
          <div>
            <label className="block">End Date</label>
            <input
              type="datetime-local"
              name="endDate"
              required
              className="border p-2 w-full"
            />
          </div>
        </div>
        <div>
          <label className="block">Role</label>
          <select name="role" required className="border p-2 w-full">
            <option value="president">President</option>
            <option value="representative">Representative</option>
            <option value="senator">Senator</option>
            <option value="governor">Governor</option>
            <option value="mayor">Mayor</option>
          </select>
        </div>

        {candidates.map((_, index) => (
          <div key={index} className="border p-4 mb-4">
            <h3 className="font-bold mb-2">Candidate {index + 1}</h3>
            <select name="candidateName" required className="border p-2 w-full">
              {politicians?.map((politician) => (
                <option key={politician.users.id} value={politician.users.id}>
                  {politician.users.firstName + " " + politician.users.lastName}
                </option>
              ))}
            </select>
          </div>
        ))}

        <div className="flex w-full gap-3">
          <button
            type="button"
            onClick={addCandidate}
            className="btn bg-pink-300 text-white p-4 rounded"
          >
            Add Another Candidate
          </button>
          <button
            type="submit"
            className="btn bg-purple-300 text-white p-4 rounded"
          >
            Create Election
          </button>
        </div>
      </Form>
    </div>
  )
}

export async function action({ request }: ActionFunctionArgs) {
  const formData = await request.formData()
  const title = formData.get("title")
  const description = formData.get("description")
  const startDate = formData.get("startDate")
  const endDate = formData.get("endDate")

  const candidateNames = formData.getAll("candidateName")

  try {
    const election = {
      title: title as string,
      description: description as string,
      startDate: new Date(startDate as string),
      endDate: new Date(endDate as string),
      type: formData.get("role") as
        | "president"
        | "senator"
        | "representative"
        | "governor"
        | "mayor",
    }
    const candidateIds = candidateNames.map((id) => Number(id))
    await createElection(election, candidateIds)
  } catch (error) {
    redirect("/error")
  }

  return redirect("/elections")
}
