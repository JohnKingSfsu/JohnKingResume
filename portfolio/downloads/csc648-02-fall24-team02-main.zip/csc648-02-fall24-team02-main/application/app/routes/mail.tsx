import React, { useState } from 'react';

const MailLayout = () => {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');

  const handleSend = () => {
    console.log('Email:', email);
    console.log('Name:', name);
    console.log('Subject:', subject);
    console.log('Message:', message);
    alert("Your question has been sent!");
  };

  return (
    <div className="flex flex-col items-center bg-gray-100 p-4 sm:p-6 lg:p-8 min-h-screen">
      <div className="bg-white shadow-md rounded-lg p-4 sm:p-6 lg:p-8 w-full max-w-xs sm:max-w-md lg:max-w-lg xl:max-w-2xl">
        <h2 className="text-xl sm:text-2xl font-semibold mb-4 text-center">Any Questions?</h2>
        
        <div className="form-control mb-4">
          <label className="label">
            <span className="label-text">Sender</span>
          </label>
          <input
            type="email"
            placeholder="you@example.com"
            className="input input-bordered w-full"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="form-control mb-4">
          <label className="label">
            <span className="label-text">Subject</span>
          </label>
          <input
            type="text"
            placeholder="Subject of your question"
            className="input input-bordered w-full"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
          />
        </div>

        <div className="form-control mb-4">
          <label className="label">
            <span className="label-text">Message</span>
          </label>
          <textarea
            placeholder="Type your question here"
            className="textarea textarea-bordered w-full"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
          ></textarea>
        </div>

        <div className="form-control mt-6">
          <button className="btn btn-primary w-full" onClick={handleSend}>
            Send Question
          </button>
        </div>
      </div>
    </div>
  );
};

export default MailLayout;