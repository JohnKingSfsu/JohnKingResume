import React, { useEffect, useState } from "react";

const UserStats: React.FC = () => {
  // user data
  const [users, setUsers] = useState<
    { id: number; name: string; posts: number; comments: number }[]
  >([]);

  // this will be for backend
  useEffect(() => {
    const fetchData = async () => {
      try {
        // hardcoaded data to see if it worked
        const data = [
          { id:1, name:"Alice Johnson", posts:12, comments:34 },
          { id:2, name: "Bob Smith", posts:8, comments:22 },
          { id:3, name:"Charlie Brown", posts: 15, comments: 45 },
          { id:4,name:"Diana Prince", posts:20, comments:50 },
        ];
        setUsers(data);
      } catch (error) {
        console.error("Error fetching user stats:", error);
      }
    };

    fetchData();
  }, []);

  const totalPosts = users.reduce((sum, user) => sum + user.posts, 0);
  const totalComments = users.reduce((sum, user) => sum + user.comments, 0);

  return (
    <div
      style={{
        padding:"20px",
        maxWidth:"800px",
        margin:"50px auto",
        backgroundColor:"#F4F0FF",
        borderRadius:"10px",
        boxShadow: "0px 4px 8px rgba(0,0,0,0.1)",
      }}
    >
      <h2
        style={{
          textAlign: "center",
          fontSize:"24px",
          color: "#6A0DAD",
          marginBottom:"20px",
        }}
      >
        User Statistics
      </h2>
      {users.length > 0 ? (
        <>
          <table
            style={{
              width:"100%",
              borderCollapse: "collapse",
              backgroundColor: "#fff",
              borderRadius:"8px",
              overflow: "hidden",
            }}
          >
            <thead>
            <tr style={{ backgroundColor:"#6A0DAD", color:"#fff" }}>
                <th
                  style={{
                    padding: "12px",
                    textAlign: "left",
                    fontSize: "16px",
                    fontWeight: "bold",
                  }}
                >
                  Name
            </th>
              <th
                  style={{
                    padding: "12px",
                    textAlign: "left",
                    fontSize: "16px",
                    fontWeight: "bold",
                  }}
                >
                  Posts
           </th>
              <th
                  style={{
                    padding: "12px",
                    textAlign:"left",
                    fontSize: "16px",
                    fontWeight:"bold",
                  }}
                >
                  Comments
                </th>
              </tr>
         </thead>
            <tbody>
              {users.map((user, index) => (
                <tr
                  key={user.id}
                  style={{
                    backgroundColor: index %2=== 0?"#EDE7F6" : "#fff",
                  }}
                >
                  <td
                    style={{
                      padding:"12px",
                      fontSize:"14px",
                      color:"#333",
                    }}
                  >
                    {user.name}
                  </td>
                  <td
                    style={{
                      padding:"12px",
                      fontSize:"14px",
                      color: "#333",
                    }}
                  >
                    {user.posts}
                  </td>
                  <td
                    style={{
                      padding:"12px",
                      fontSize:"14px",
                      color:"#333",
                    }}
                  >
                    {user.comments}
                  </td>
                </tr>
              ))}
            </tbody>
         </table>
       <div
            style={{
              marginTop: "20px",
              padding: "20px",
              backgroundColor: "#fff",
              borderRadius:"8px",
              boxShadow:"0px 2px 4px rgba(0, 0, 0, 0.1)",
            }}
          >
            <p
              style={{
                fontSize:"18px",
                color:"#6A0DAD",
                fontWeight: "bold",
              marginBottom: "8px",
              }}
            >
              Total Posts: {totalPosts}
            </p>
           <p
              style={{
                fontSize:"18px",
                color:"#6A0DAD",
                fontWeight:"bold",
              }}
            >
            Total Comments: {totalComments}
            </p>
        </div>
        </>
      ) : (
      <p
          style={{
            textAlign:"center",
            color:"#6A0DAD",
            fontSize:"18px",
          }}
        >
          Loading user stats...
       </p>
      )}
    </div>
  );
};

export default UserStats;
