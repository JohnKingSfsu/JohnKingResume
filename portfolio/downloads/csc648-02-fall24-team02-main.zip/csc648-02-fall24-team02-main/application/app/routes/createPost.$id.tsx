import {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  redirect,
} from "@remix-run/node"
import { Form } from "@remix-run/react"
import { authenticator } from "backend/services/auth/auth"
import { insertPost } from "backend/models/posts"

export async function loader({ request, params }: LoaderFunctionArgs) {
  const user = await authenticator.isAuthenticated(request, {
    failureRedirect: "/error",
  })

  const { id } = params; // Directly use params from LoaderFunctionArgs

  // Ensure both are strings for comparison
  if (user.id.toString() !== id) {
    return redirect("/login");
  }

  return{user,id}
}

export default function makePost() {
  return (
    <Form
      method="post"
      className="flex flex-col h-full w-full justify-center items-center gap-4"
    >
      <div className="w-2/3 md:w-1/3">
        <h1 className="text-4xl font-bold py-4">Make Your Post</h1>
        <div className="form-control">
          <label className="label">
            <span className="label-text">Post</span>
          </label>
          <input
            type="PostText"
            name="Post"
            placeholder="message..."
            className="input input-bordered"
            required
          />
          <button type="submit" className="btn">
            confirm post
          </button>
        </div>
      </div>
    </Form>
  )
}

export async function action({ request, params }: ActionFunctionArgs) {
  try {
    const data = await request.formData()
    console.log(data)
    console.log(params.id)

    const postData = {
      id: Number(null),
      posterId: Number(params.id),
      text: data.get("Post")?.toString() || "",
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    const response = await insertPost(postData)

    return redirect(`/forum/${params.id}`)
  } catch (error) {
    console.error(error)
    return redirect("/error")
  }
}
