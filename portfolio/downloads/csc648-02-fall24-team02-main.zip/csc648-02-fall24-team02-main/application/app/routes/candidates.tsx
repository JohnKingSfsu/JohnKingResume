import { Link, useOutletContext } from "@remix-run/react";
import { Divide, Smile } from "lucide-react";
import { useEffect } from "react";
import { ContextType } from "~/types";

export default function Candidates() {
  const { handleTitleChange } = useOutletContext<ContextType>();

  useEffect(() => {
    handleTitleChange("Meet the Candidates");
  }, [handleTitleChange]);

  const candidates = [
    {
      name: "London Breed",
      position: "Mayor",
      imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fd/Mayor_London_Breed_official_portrait_2019.jpg/330px-Mayor_London_Breed_official_portrait_2019.jpg", // Example image URL
    },
    {
      name: "Jared Huffman",
      position: "Representative",
      imageUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d2/Jared_Huffman_Portrait_118.jpg/330px-Jared_Huffman_Portrait_118.jpg" // Example image URL
    },
    {
      name: "Jessica Morse",
      position: "Senate",
      imageUrl: "https://assets.civicengine.com/uploads/candidate/headshot/155997/155997.jpg", // Example image URL
    },
    {
      name: "Kevin Kiley",
      position: "Mayor",
      imageUrl: "https://upload.wikimedia.org/wikipedia/commons/9/99/Rep._Kevin_Kiley_official_photo%2C_118th_Congress_2.jpg", // Example image URL
    },
    {
      name: "Mike Thompson",
      position: "Representative",
      imageUrl: "https://upload.wikimedia.org/wikipedia/commons/f/f1/Mike_Thompson%2C_official_portrait%2C_116th_Congress.jpg", // Example image URL
    },
    {
      name: "Mark Farrell",
      position: "Senate",
      imageUrl: "https://sfbos.org/sites/default/files/farrell.jpg", // Example image URL
    },
  ];

  return (
    <div className="p-4">
      {/* Flex container to arrange the input and candidates side by side */}
      <div className="flex">
        <div className="w-1/3 mr-1">
          {/* Simple Input Box */}
          <input
            type="text"
            placeholder="Search"
            className="border border-gray-900 rounded px-3 py-2 w-64"
          />
          <br/>
          <br/>
          <h3>Party</h3>
          <div className="mt-4">
            <label className="flex items-center mb-2">
              <input type="checkbox" className="mr-2" />
              Democrat
            </label>
            <label className="flex items-center mb-2">
              <input type="checkbox" className="mr-2" />
              Republican
            </label>
          </div>
          <br />
          <h3>Position</h3>
          <div className="mt-4">
            <label className="flex items-center mb-2">
              <input type="checkbox" className="mr-2" />
              Mayor
            </label>
            <label className="flex items-center mb-2">
              <input type="checkbox" className="mr-2" />
              Representative
            </label>
            <label className="flex items-center mb-2">
              <input type="checkbox" className="mr-2" />
              Senate
            </label>
          </div>
        </div>

        {/* Candidates section to the right of the input */}
        <div className="w-2/3">
          <div className="mt-2 grid grid-cols-3 gap-4">
            {candidates.map((candidate, index) => (
              <div key={index} className="text-center border border-gray-900 p-4 rounded-lg">
                <img
                  src={candidate.imageUrl}
                  alt={candidate.name}
                  className="w-32 h-32 object-cover rounded-full mx-auto"
                />
                <h4 className="mt-2 text-lg font-semibold">{candidate.name}</h4>
                <p className="text-gray-500">{candidate.position}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}