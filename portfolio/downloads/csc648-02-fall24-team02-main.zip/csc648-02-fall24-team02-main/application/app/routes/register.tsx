import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node"
import { Form, Link } from "@remix-run/react"
import { authenticator } from "backend/services/auth/auth"

export async function loader({ request }: LoaderFunctionArgs) {
  return await authenticator.isAuthenticated(request, {
    successRedirect: "/dashboard",
  })
}

export default function Register() {
  return (
    <Form
      method="post"
      className="flex flex-col h-full w-full justify-center items-center gap-4"
    >
      <div className="w-2/3 md:w-1/3">
        <h1 className="text-4xl font-bold py-4">Registration</h1>
        <div className="form-control">
          <label className="label">
            <span className="label-text">First Name</span>
          </label>
          <input
            type="first-name"
            name="first-name"
            placeholder="Ada"
            className="input input-bordered"
            required
          />
        </div>
        <div className="form-control">
          <label className="label">
            <span className="label-text">Last Name</span>
          </label>
          <input
            type="last-name"
            name="last-name"
            placeholder="Lovelace"
            className="input input-bordered"
            required
          />
        </div>
        <div className="form-control">
          <label className="label">
            <span className="label-text">Email</span>
          </label>
          <input
            type="email"
            name="email"
            placeholder="email"
            className="input input-bordered"
            required
          />
        </div>
        <div className="form-control">
          <label className="label">
            <span className="label-text">Password</span>
          </label>
          <input
            name="password"
            type="password"
            placeholder="password"
            className="input input-bordered"
            required
          />
        </div>
        <div className="form-control">
          <label className="label">
            <span className="label-text">Confirm Password</span>
          </label>
          <input
            name="confirm-password"
            type="password"
            placeholder="confirm password"
            className="input input-bordered"
            required
          />
          <label className="label">
            <Link to="/login" className="label-text-alt link link-hover">
              Want to login instead?
            </Link>
          </label>
        </div>
        <div className="form-control mt-6">
          <button className="btn bg-violet-500 text-white" type="submit">
            Create an acccount
          </button>
        </div>
      </div>
    </Form>
  )
}

export async function action({ request }: ActionFunctionArgs) {
  const formData = await request.formData()
  return await authenticator.authenticate("form-register", request, {
    successRedirect: "/",
    failureRedirect: "/register",
    context: { formData },
  })
}
