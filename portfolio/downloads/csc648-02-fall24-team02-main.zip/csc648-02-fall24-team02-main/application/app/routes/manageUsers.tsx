import React, { useState } from 'react';

type User = {
  id: number;
  name: string;
  email: string;
  role: string;
};

const initialUsers: User[] = [
  { id: 1, name:'John Doe', email:'john@example.com',role: 'Admin' },
  { id: 2, name:'Jane Smith',email: 'jane@example.com', role: 'User' },
  { id: 3, name:'Sam Johnson',email:'sam@example.com', role: 'Moderator' },
];

export async function loader() {
}

const ManageUsers = () => {
  const [users, setUsers] = useState<User[]>(initialUsers);

  const handleEdit = (id: number) => {
    alert(`Edit user with ID: ${id}`);

  };

  const handleDelete = (id: number) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      setUsers(users.filter(user => user.id !== id));
    }
  };

  return (
    <div className="flex flex-col items-center p-8 min-h-screen bg-gray-100">
      <div className="bg-white shadow-lg rounded-lg p-8 w-full max-w-4xl">
        <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">Manage Users</h2>

        <table className="table-auto w-full text-left">
          <thead>
            <tr>
              <th className="px-4 py-2 border-b">Name</th>
              <th className="px-4 py-2 border-b">Email</th>
              <th className="px-4 py-2 border-b">Role</th>
              <th className="px-4 py-2 border-b">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map(user => (
              <tr key={user.id}>
                <td className="px-4 py-2 border-b">{user.name}</td>
                <td className="px-4 py-2 border-b">{user.email}</td>
                <td className="px-4 py-2 border-b">{user.role}</td>
                <td className="px-4 py-2 border-b">
                  <button
                    onClick={() => handleEdit(user.id)}
                    className="btn btn-sm btn-primary mr-2"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(user.id)}
                    className="btn btn-sm btn-error"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ManageUsers;
