import { createPool } from "mysql2/promise"

const dbpool = createPool({
  host: "localhost",
  port: "3306",
  user: "root",
  password: "root-testing123",
  database: "csc648",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
})

async function createDatabase() {
  const conn = await createPool({
    host: "localhost",
    user: "root",
    password: "root-testing123",
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
  }).getConnection()

  try {
    // Create the database if it does not exist
    await conn.query(`CREATE DATABASE IF NOT EXISTS csc648`)
    console.log("Database created successfully.")
  } catch (error) {
    console.error("Error creating database:", error)
  } finally {
    conn.release()
  }
}

async function createTables() {
  const conn = await dbpool.getConnection()
  try {
    await conn.beginTransaction()

    await conn.query(`
        CREATE TABLE IF NOT EXISTS administrator (
            work_id INT NOT NULL AUTO_INCREMENT,
            name VARCHAR(50) NOT NULL,
            password CHAR(100) NOT NULL,
            PRIMARY KEY (work_id)
          );
        `)

    await conn.query(`
        CREATE TABLE IF NOT EXISTS user (
            user_id INT NOT NULL AUTO_INCREMENT,
            username CHAR(100) NOT NULL,
            dob DATE NOT NULL,
            password CHAR(100) NOT NULL,
            PRIMARY KEY (user_id)
            );
        `)

    await conn.query(`
        CREATE TABLE IF NOT EXISTS candidate_position (
            position_id INT NOT NULL AUTO_INCREMENT,
            name VARCHAR(50) NOT NULL,
            description MEDIUMTEXT NOT NULL,
            candidate_id INT NOT NULL,
            PRIMARY KEY (position_id, candidate_id),
            INDEX FK_CANDIDATE_POSITION (candidate_id ASC) VISIBLE
            );
        `)

    await conn.query(`
        CREATE TABLE IF NOT EXISTS policies (
            policy_id INT NOT NULL AUTO_INCREMENT,
            name VARCHAR(50) NOT NULL,
            description MEDIUMTEXT NOT NULL,
            candidate_id INT NOT NULL,
            PRIMARY KEY (policy_id, candidate_id),
            INDEX FK_CANDIDATE_POLICIES (candidate_id ASC) VISIBLE
            );
        `)

    await conn.query(`
        CREATE TABLE IF NOT EXISTS congressional_district (
            congressional_district_id INT NOT NULL AUTO_INCREMENT,
            name CHAR(50) NOT NULL,
            candidate_id INT NOT NULL,
            PRIMARY KEY (congressional_district_id, candidate_id),
            INDEX FK_CANDIDATE_CONGRESSIONAL_DISTRICT (candidate_id ASC) VISIBLE
            );
        `)

    await conn.query(`
        CREATE TABLE IF NOT EXISTS rating (
            rating_id INT NOT NULL AUTO_INCREMENT,
            politician_rating TINYINT,
            candidate_id INT NOT NULL,
            PRIMARY KEY (rating_id, candidate_id),
            INDEX FK_CANDIDATE_RATING (candidate_id ASC) VISIBLE
            );
        `)

    await conn.query(`
        CREATE TABLE IF NOT EXISTS candidate (
            candidate_id INT NOT NULL AUTO_INCREMENT,
            name VARCHAR(50) NOT NULL,
            party CHAR(50) NOT NULL,
            political_experience MEDIUMTEXT NOT NULL,
            PRIMARY KEY (candidate_id));
            `)

    await conn.query(`
            CREATE TABLE IF NOT EXISTS voter_registration (
                title CHAR(50) NOT NULL,
                description MEDIUMTEXT NOT NULL,
                PRIMARY KEY (title)
                );
            `)

    await conn.query(`
            CREATE TABLE IF NOT EXISTS voting_process (
                title CHAR(50) NOT NULL,
                description MEDIUMTEXT NOT NULL,
                PRIMARY KEY (title)
                );
            `)

    await conn.query(`
            CREATE TABLE IF NOT EXISTS current_location (
                booth_id INT NOT NULL AUTO_INCREMENT,
                location GEOMETRY NOT NULL,
                candidate VARCHAR(50) NOT NULL,
                voting_rules MEDIUMTEXT NULL,
                PRIMARY KEY (booth_id)
                );
            `)

    await conn.query(`
            CREATE TABLE IF NOT EXISTS message (
                message_id INT NOT NULL AUTO_INCREMENT,
                message MEDIUMTEXT NOT NULL,
                sender VARCHAR(50) NOT NULL,
                receiver VARCHAR(50) NULL,
                PRIMARY KEY (message_id)
                );
            `)

    await conn.commit()
  } catch (err) {
    console.error(err)
    await conn.rollback()
  } finally {
    conn.release()
  }
}

async function populateAdministrator() {
  const conn = await dbpool.getConnection()

  try {
    await conn.query(
      `INSERT IGNORE INTO administrator (work_id, name, password) VALUES
            (?, ?, ?)`,
      [2000, "Daniel Mills", "DanielMillsPassword"]
    )
  } finally {
    conn.release()
  }
}

async function populateUser() {
  const conn = await dbpool.getConnection()

  try {
    await conn.query(
      `INSERT IGNORE INTO user (user_id, username, dob, password) VALUES
            (?, ?, ?, ?),
            (?, ?, ?, ?)`,
      [
        1000,
        "EmmaRonnie",
        "2003-09-27",
        "EmmaRonnie216",
        1001,
        "JohnHopkins",
        "1979-08-27",
        "JohnHopkins199",
      ]
    )
  } finally {
    conn.release()
  }
}

async function populateVotingProcess() {
  const conn = await dbpool.getConnection()

  try {
    await conn.query(
      `INSERT IGNORE INTO voting_process (title, description) VALUES
            (?, ?),
            (?, ?)`,
      [
        "Voting",
        "Ballots are mailed to every registered citizen in the country. Fill out the ballot and leave it in a drop box before Election Day.",
        "First Time Voters",
        "First time voters must bring an ID in order to vote in the election",
      ]
    )
  } finally {
    conn.release()
  }
}

async function populateVoterRegistration() {
  const conn = await dbpool.getConnection()

  try {
    await conn.query(
      `INSERT IGNORE INTO voter_registration (title, description) VALUES
            (?, ?),
            (?, ?)`,
      [
        "Citizenship",
        "United States adult citizens may vote (some areas allow non-citizens to vote in local elections)",
        "Residency",
        "Voters must be residents of their State",
      ]
    )
  } finally {
    conn.release()
  }
}

async function populateMessage() {
  const conn = await dbpool.getConnection()

  try {
    await conn.query(
      `INSERT IGNORE INTO message (message_id, message, sender, receiver) VALUES
            (?, ?, ?, ?)`,
      [4000, null, null, null]
    )
  } finally {
    conn.release()
  }
}

async function populateCongressionalDistrict() {
  const conn = await dbpool.getConnection()

  try {
    await conn.query(
      `INSERT IGNORE INTO congressional_district (name, candidate_id) VALUES
            (?, ?),
            (?, ?),
            (?, ?),
            (?, ?),
            (?, ?),
            (?, ?),
            (?, ?)`,
      [
        "District 2",
        1,
        "District 2",
        2,
        "District 3",
        3,
        "District 3",
        4,
        "District 4",
        5,
        "District 11",
        6,
        "District 11",
        7,
      ]
    )
  } finally {
    conn.release()
  }
}

async function populateRating() {
  const conn = await dbpool.getConnection()

  try {
    await conn.query(
      `INSERT IGNORE INTO rating (politician_rating, candidate_id) VALUES
            (?, ?),
            (?, ?),
            (?, ?),
            (?, ?),
            (?, ?),
            (?, ?),
            (?, ?)`,
      [
        null,
        1, // politician_rating for candidate 1
        null,
        2, // politician_rating for candidate 2
        null,
        3, // politician_rating for candidate 3
        null,
        4, // politician_rating for candidate 4
        null,
        5, // politician_rating for candidate 5
        null,
        6, // politician_rating for candidate 5
        null,
        7, // politician_rating for candidate 5
      ]
    )
  } finally {
    conn.release()
  }
}

async function populatePosition() {
  const conn = await dbpool.getConnection()

  try {
    await conn.query(
      `INSERT IGNORE INTO candidate_position (name, description, candidate_id) VALUES
            (?, ?, ?),
            (?, ?, ?),
            (?, ?, ?),
            (?, ?, ?),
            (?, ?, ?),
            (?, ?, ?),
            (?, ?, ?)`,
      [
        "Representative",
        "Congress representing different congressional districts",
        1,
        "Representative",
        "Congress representing different congressional districts",
        2,
        "Representative",
        "Congress representing different congressional districts",
        3,
        "Representative",
        "Congress representing different congressional districts",
        4,
        "Representative",
        "Congress representing different congressional districts",
        5,
        "Mayor",
        "Position representing a city",
        6,
        "Mayor",
        "Position representing a city",
        7,
      ]
    )
  } finally {
    conn.release()
  }
}

async function populatePolicies() {
  const conn = await dbpool.getConnection()

  try {
    await conn.query(
      `INSERT IGNORE INTO policies (name, description, candidate_id) VALUES
            (?, ?, ?),
            (?, ?, ?),
            (?, ?, ?),
            (?, ?, ?),
            (?, ?, ?),
            (?, ?, ?),
            (?, ?, ?)`,
      [
        "Climate Change",
        "Climate change to be addressed through policy",
        1,
        "Education",
        "Education to be addressed by providing resources to schools",
        2,
        "Support for Seniors",
        "Seniors to be promised financial security",
        3,
        "Fire Prevention",
        "Action taken to prevent fires",
        4,
        "Affordable Education",
        "Action to be taken to make college affordable",
        5, // Corrected the second 'Education' entry to be unique
        "Transportation",
        "Action to make public transportation more available",
        6,
        "Public Safety",
        "Action to make the area more safe",
        7,
      ]
    )
  } finally {
    conn.release()
  }
}

async function populateCandidate() {
  const conn = await dbpool.getConnection()

  try {
    await conn.query(
      `INSERT IGNORE INTO candidate (candidate_id, name, party, political_experience) VALUES
            (?, ?, ?, ?),
            (?, ?, ?, ?),
            (?, ?, ?, ?),
            (?, ?, ?, ?),
            (?, ?, ?, ?),
            (?, ?, ?, ?),
            (?, ?, ?, ?)`,
      [
        1,
        "Jared Huffman",
        "Democrat",
        "State Representative",
        2,
        "Chris Coulombe",
        "Republican",
        "Veteran",
        3,
        "Jessica Morse",
        "Democrat",
        "Representative Candidate",
        4,
        "Kevin Kiley",
        "Republican",
        "State Assembly, State Senate, State Assembly, Governor, U.S. House",
        5,
        "Mike Thompson",
        "Democrat",
        "State Representative",
        6,
        "London Breed",
        "Democrat",
        " San Francisco Mayor",
        7,
        "Mark Farrell",
        "Democrat",
        " State Representative",
      ]
    )
  } finally {
    conn.release()
  }
}

async function initDB() {
  createTables()
  populateCongressionalDistrict()
  populateRating()
  populatePosition()
  populatePolicies()
  populateCandidate()
  populateAdministrator()
  populateUser()
  populateVoterRegistration()
  populateVotingProcess()
  populateMessage()

  console.log("Database initialized successfully.")
}

initDB()
process.exit(0)
