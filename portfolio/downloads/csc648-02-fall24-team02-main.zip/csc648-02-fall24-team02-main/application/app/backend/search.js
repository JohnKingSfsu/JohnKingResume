import express from "express"
import { db } from "./db" // Import the MySQL connection pool from db.js

const router = express.Router()

// Helper function for validation
const isValidSearchTerm = (term) => {
  const regex = /^[a-zA-Z0-9]*$/ // Allow only alphanumeric characters
  return regex.test(term) && term.length <= 40 // Max length 40
}

//Search function
router.get("/search", async (req, res) => {
  const searchTerm = req.query.term || ""
  const filter = req.query.filter || "name" // Default filter is 'name'

  if (!isValidSearchTerm(searchTerm)) {
    return res.status(400).json({ error: "Invalid search term." })
  }

  // Var from m2 doc. May need changing, unsure how the SQL database is set up
  let query = `
    SELECT DISTINCT
      c.name AS candidate_name,
      c.party,
      c.political_experience,
      p.name AS position_name,
      pol.name AS policy_name
    FROM candidate c
    LEFT JOIN candidate_position p ON c.candidate_id = p.candidate_id
    LEFT JOIN policies pol ON c.candidate_id = pol.candidate_id
  `

  let params = []

  // Filter Results
  if (searchTerm) {
    switch (filter) {
      case "name":
        query += ` WHERE c.name LIKE ?`
        break
      case "candidate_position":
        query += ` WHERE p.name LIKE ?`
        break
      case "party":
        query += ` WHERE c.party LIKE ?`
        break
      case "policy":
        query += ` WHERE pol.name LIKE ?`
        break
      default:
        // Fallback to candidate name
        query += ` WHERE c.name LIKE ?`
        break
    }
    params.push(`%${searchTerm}%`)
  }

  // Prioritize candidates for display
  query += ` ORDER BY c.name`

  // Run search query
  try {
    // Execute the query using the connection pool
    const [results] = await db.query(query, params)

    // If no results found, return all candidates
    if (results.length === 0) {
      const [allCandidates] = await db.query(`
        SELECT DISTINCT
          c.name AS candidate_name,
          c.party,
          c.political_experience,
          p.name AS position_name,
          pol.name AS policy_name
        FROM candidate c
        LEFT JOIN candidate_position p ON c.candidate_id = p.candidate_id
        LEFT JOIN policies pol ON c.candidate_id = pol.candidate_id
        ORDER BY c.name
      `)
      return res.json(allCandidates)
    }

    // Send the results back to the frontend
    return res.json(results)
  } catch (err) {
    console.error("Database query error:", err)
    return res.status(500).json({ error: "Database query error" })
  }
})

export default router
