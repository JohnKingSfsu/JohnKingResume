import express from "express"
import { db } from "./db"

const msgRouter = express.Router()

msgRouter.post("/send/:id", async (req, res) => {
  try {
    const { id } = req.params
    const { user, message } = req.body

    const receiver = await db.query("SELECT * FROM users WHERE user_id = ?", [
      id,
    ])
    if (!receiver) {
      return res.status(404).send("User not found")
    }

    if (!user || !message) {
      return res.status(400).send("Invalid request")
    }

    const msg = await db.query(
      "INSERT INTO messages (sender, receiver, message) VALUES (?, ?, ?)",
      [user, id, message]
    )
    res.status(201).send(msg)
  } catch (error) {
    res.status(500).send("Internal Server Error")
  }
})

msgRouter.get("/inbox/:id", async (req, res) => {
  try {
    const { id } = req.params
    const messages = await db.query(
      "SELECT * FROM messages WHERE receiver = ?",
      [id]
    )
    res.status(200).send(messages)
  } catch (error) {
    res.status(500).send("Internal Server Error")
  }
})
