import { useState } from 'react';
import { Link, useNavigate } from '@remix-run/react';

export default function Navbar() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('name'); // Default filter is 'name'
  const navigate = useNavigate();

  // Handle search form
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Redirect to results page
    navigate(`/results?term=${searchTerm}&filter=${filter}`);
  };

  return (
    <nav className="fixed top-0 left-0 w-full bg-purple-600 p-4 flex justify-between items-center text-white shadow-md z-10">
      
      <div>
        <Link to="/" className="font-bold text-xl">Political IQ</Link>
      </div>

      
      <ul className="flex space-x-4">
        <li>
          <Link to="/about" className="hover:text-gray-300">About</Link>
        </li>
        <li>
          <Link to="/candidates" className="hover:text-gray-300">Candidates</Link>
        </li>
        <li>
          <Link to="/faq" className="hover:text-gray-300">FAQ</Link>
        </li>

        <li>
          <Link to="/login" className="hover:text-gray-300">Log In</Link>
        </li>
      </ul>
   
      <form onSubmit={handleSearch} className="flex items-center space-x-4">
        
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="p-2 bg-white text-black rounded-md"
        >
          <option value="name">Candidate Name</option>
          <option value="position">Position</option>
          <option value="policy">Policy</option>
        </select>

        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search..."
          className="p-2 rounded-md text-black"
        />

        <button type="submit" className="ml-2 p-2 bg-gray-500 rounded-md hover:bg-gray-400">
          Search
        </button>
      </form>
    </nav>
  );
}