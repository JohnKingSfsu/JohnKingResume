import {
  Form,
  isRouteErrorResponse,
  Link,
  Links,
  Meta,
  Outlet,
  Scripts,
  ScrollRestoration,
  useLoaderData,
  useRouteError,
} from "@remix-run/react"
import "./tailwind.css"
import { useState } from "react"
import {
  Book,
  GraduationCap,
  Handshake,
  LayoutDashboard,
  Menu,
  Search,
  Sparkles,
  TicketCheck,
  Vote,
  BotMessageSquare,
  Mail,
  Twitter,
  Magnet,
  BookMarked,
} from "lucide-react"
import { authenticator } from "backend/services/auth/auth"
import { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node"
import { User } from "backend/models/user"

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <Meta />
        <Links />
        <script
          async
          src={`https://www.googletagmanager.com/gtag/js?id=G-C9DCD49SL5`}
        ></script>
        <script
          dangerouslySetInnerHTML={{
            __html: `
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-C9DCD49SL5', {
        page_path: window.location.pathname,
        });
    `,
          }}
        />{" "}
      </head>
      <body>
        {children}
        <ScrollRestoration />
        <Scripts />
      </body>
    </html>
  )
}

export async function loader({ request }: LoaderFunctionArgs) {
  const user = authenticator.isAuthenticated(request)
  return user
}

export default function App() {
  const user = useLoaderData<User>()

  const [title, setTitle] = useState("")
  const handleTitleChange = (newTitle: string) => {
    setTitle(newTitle)
  }

  return (
    <div className="drawer drawer-end h-screen">
      <input id="my-drawer-3" type="checkbox" className="drawer-toggle" />
      <CookiesWarning />
      <div className="drawer-content flex flex-col">
        {/* Navbar */}
        <div className="navbar p-2">
          <Link
            to="/"
            className="navbar-start text-3xl font-semibold text-violet-500 gap-4"
          >
            <Sparkles />
            PoliticalQ
          </Link>
          <div className="navbar-center font-semibold text-2xl hidden md:block">
            {title}
          </div>
          <div className="navbar-end">
            <label
              htmlFor="my-drawer-3"
              aria-label="open sidebar"
              className="btn btn-square btn-ghost"
            >
              <Menu />
            </label>
          </div>
        </div>
        <Outlet context={{ handleTitleChange }} />
      </div>
      <div className="drawer-side z-50">
        <label
          htmlFor="my-drawer-3"
          aria-label="close sidebar"
          className="drawer-overlay"
        ></label>
        <ul className="menu bg-base-200 min-h-full w-80 p-4">
          {/* Sidebar content here */}
          <p className="text-xs">
            SFSU Software Engineering Project CSC 648-848, Fall 2024. For
            Demonstration Only
          </p>
          {user && user.userRole === "admin" && (
            <li>
              <Link to="/admin" className="text-xl">
                <Magnet />
                <p className="text-xl font-semibold">Admin</p>
              </Link>
            </li>
          )}
          <li>
            <Link to="/intro" className="text-xl">
              <Book />
              <p className="text-xl font-semibold">Intro to Parties</p>
            </Link>
          </li>
          <li>
            <Link to="/votermap" className="text-xl">
              <Vote />
              <p className="text-xl font-semibold">How to vote</p>
            </Link>
          </li>
          <li>
            <Link to="/about" className="text-xl">
              <GraduationCap />
              <p className="text-xl font-semibold">About our team</p>
            </Link>
          </li>
          {user && (
            <div>
              <li>
                <Link to="/inbox" className="text-xl">
                  <Mail />
                  <p className="text-xl font-semibold">Inbox</p>
                </Link>
              </li>
              <li>
                <Link to={`/forum/${user.id}`} className="text-xl">
                  <Twitter />
                  <p className="text-xl font-semibold">Posts</p>
                </Link>
              </li>
              <li>
                <Link to="/elections" className="text-xl">
                  <TicketCheck />
                  <p className="text-xl font-semibold">Elections</p>
                </Link>
              </li>
              <li>
                <Link to="/dashboard" className="text-xl">
                  <BookMarked />
                  <p className="text-xl font-semibold">Profile</p>
                </Link>
              </li>
            </div>
          )}
          <li>
            <Link to="/chatbot" className="text-xl">
              <BotMessageSquare />
              <p className="text-xl font-semibold">AI Assistant</p>
            </Link>
          </li>
          <li>
            <Link to="/search" className="text-xl">
              <Search />
              <p className="text-xl font-semibold">Search</p>
            </Link>
          </li>
          <li className="mt-auto md:mt-4 flex flex-row justify-center">
            {user ? (
              <Form method="post">
                <button
                  type="submit"
                  className="btn bg-violet-500 text-white font-semibold text-lg w-full"
                >
                  Logout
                </button>
              </Form>
            ) : (
              <Link
                to="/login"
                className="btn bg-violet-500 text-white font-semibold w-full text-xl"
              >
                Login
              </Link>
            )}
          </li>
        </ul>
      </div>
    </div>
  )
}

function CookiesWarning() {
  const [show, setShow] = useState(() => true)

  const handleAccept = () => {
    setShow(false)
  }

  if (!show) return null

  return (
    <div className="fixed bottom-5 left-5 m-2 w-96 bg-white p-4 rounded-lg shadow-lg z-100">
      <p className="py-4">
        We use cookies to collect analytics and to store user data. By
        continuing you agree to our use of cookies.
      </p>
      <button
        onClick={handleAccept}
        className="btn btn-sm bg-violet-500 text-white"
      >
        I understand
      </button>
    </div>
  )
}

export function ErrorBoundary() {
  const error = useRouteError()

  if (isRouteErrorResponse(error)) {
    return (
      <div className="h-screen flex flex-col items-center justify-center gap-4">
        <h1 className="text-4xl md:text-6xl text-violet-500 font-semibold">
          {error.status} {error.statusText}
        </h1>
        <p className="text-xl text-wrap">{error.data}</p>
        <Link className="btn" to="/">
          Back to PoliticalQ
        </Link>
      </div>
    )
  } else if (error instanceof Error) {
    return (
      <div>
        <h1 className="text-4xl md:text-6xl text-violet-500 font-semibold">
          Error
        </h1>
        <p className="text-2xl">{error.message}</p>
        <p className="text-xl">The stack trace is:</p>
        <pre>{error.stack}</pre>
      </div>
    )
  } else {
    return (
      <h1 className="text-6xl text-violet-500 font-semibold">Unknown Error</h1>
    )
  }
}

export async function action({ request }: ActionFunctionArgs) {
  return authenticator.logout(request, {
    redirectTo: "/",
  })
}
