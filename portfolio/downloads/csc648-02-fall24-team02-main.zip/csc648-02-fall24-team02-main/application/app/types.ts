export type ContextType = {
  handleTitleChange: (title: string) => void
}
