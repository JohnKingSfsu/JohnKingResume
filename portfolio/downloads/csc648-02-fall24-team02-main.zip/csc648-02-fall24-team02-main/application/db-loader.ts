import "dotenv/config"
import { drizzle, MySql2DrizzleConfig } from "drizzle-orm/mysql2"
import { eq, sql, desc, count } from "drizzle-orm"
import mysql from "mysql2/promise"
import { faker } from "@faker-js/faker"
import {
  users,
  politicians,
  policies,
  locations,
  pollingLocations,
  userLocations,
  elections,
  electionCandidates,
  electionVotes,
  userCredentials,
} from "backend/services/db/schema.ts"
import { db } from "backend/services/db/index.ts"

await db.delete(electionVotes)
await db.delete(politicians)
await db.delete(policies)
await db.delete(userLocations)
await db.delete(electionCandidates)
await db.delete(pollingLocations)
await db.delete(elections)
await db.delete(locations)
await db.delete(userCredentials)
await db.delete(users)

async function seed() {

  // array parties for randomization
  const party = ["republican", "democrat", "independant"]
  const partyRand = 0

  // array position for randomization
  const position = ["president", "representative"]
  const positionRand = 0

  // populate user tables with random values 1-99
  for (let i = 1; i < 100; i++) {
    // get random party
    const partyRand = Math.floor(Math.random() * party.length)
    await db.insert(users).values([
      {
        id: i,
        firstName: faker.person.firstName(),
        lastName: faker.person.lastName(),
        party: party[partyRand],
        age: 100,
        profilePicture: faker.image.urlLoremFlickr({ category: 'people', height: 160, width: 160 }),
      },
    ])
  }

  // populate id 100-149 with politicians
  for (let j = 100; j < 150; j++) {
    const partyRand = Math.floor(Math.random() * party.length)
    await db.insert(users).values([
      {
        id: j,
        firstName: faker.person.firstName(),
        lastName: faker.person.lastName(),
        userRole: "politician",
        party: party[partyRand],
        age: 100,
        profilePicture: `https://i.pravatar.cc/150?img=${j-99}`,
      },
    ])

    // block to retrieve userId of all politicians
    var usersid = await db
      .select({ userId: users.id })
      .from(users)
      .where(eq(users.userRole, "politician"))
      .orderBy(desc(users.id))
      .limit(1)
    var usersidString = JSON.stringify(usersid)
    var realId = usersidString.slice(
      usersidString.indexOf(":") + 1,
      usersidString.indexOf("}")
    )

    //get random position
    const positionRand = Math.floor(Math.random() * position.length)

    // insert random values into politicians
    await db.insert(politicians).values([
      {
        positionEnum: position[positionRand],
        userId: realId,
      },
    ])
  }

  // populate policy
  await db.insert(policies).values([
    {
      author: faker.person.fullName(),
      type: "foreign policy",
      description: "Action taken to improve connections between the nations",
      supports: faker.number.int({ min: 0, max: 1 }),
    },
    {
      author: faker.person.fullName(),
      type: "social justice",
      description: "Action taken to improve equality and social rights",
      supports: faker.number.int({ min: 0, max: 1 }),
    },
    {
      author: faker.person.fullName(),
      type: "technology",
      description: "Action taken to control technological limits and rights",
      supports: faker.number.int({ min: 0, max: 1 }),
    },
    {
      author: faker.person.fullName(),
      type: "infrastructure",
      description:
        "Action taken to improve cities architecture and infrastructure",
      supports: faker.number.int({ min: 0, max: 1 }),
    },
    {
      author: faker.person.fullName(),
      type: "climate change",
      description: "Action taken to reduce climate change",
      supports: faker.number.int({ min: 0, max: 1 }),
    },
    {
      author: faker.person.fullName(),
      type: "education",
      description: "Action taken to improve the educational system",
      supports: faker.number.int({ min: 0, max: 1 }),
    },
    {
      author: faker.person.fullName(),
      type: "healthcare",
      description: "Action taken to make healthcare more available",
      supports: faker.number.int({ min: 0, max: 1 }),
    },
    {
      author: faker.person.fullName(),
      type: "gun control",
      description: "Action taken to control gun laws",
      supports: faker.number.int({ min: 0, max: 1 }),
    },
  ])

  // get number of total users in realTotal
  var totalUsers = await db.select({ count: count() }).from(users)
  var totalUsersString = JSON.stringify(totalUsers)
  var realTotal = totalUsersString.slice(
    totalUsersString.indexOf(":") + 1,
    totalUsersString.indexOf("}")
  )

  // randomize locations for every user
  for (let i = 1; i < realTotal; i++) {
    await db.insert(locations).values([
      {
        id: i,
        line1: faker.location.streetAddress(false),
        line2: faker.location.secondaryAddress(),
        city: faker.location.city(),
        state: faker.location.state(),
        country: faker.location.country(),
      },
    ])
  }

  // create election type
  await db.insert(elections).values([
    {
      id: 1,
      type: "representative",
      title: "Representative Election",
      description:
        "An election to elect representatives based on Electoral District",
      startDate: faker.date.past(),
      endDate: faker.date.soon(),
    },
    {
      id: 2,
      type: "president",
      title: "Presidential Election",
      description: "An election to elect the president",
      startDate: faker.date.past(),
      endDate: faker.date.soon(),
    },
    {
      id: 3,
      type: "mayor",
      title: "Mayoral Election",
      description: "An election to elect the mayor based on city",
      startDate: faker.date.past(),
      endDate: faker.date.soon(),
    },
  ])

  // randomize polling locations
  for (let i = 1; i < realTotal; i++) {
    await db.insert(pollingLocations).values([
      {
        locationId: i,
        electionId: faker.number.int({ min: 1, max: 3 }),
      },
    ])
  }

  // get a random location from table and put it in userlocations
  for (let i = 1; i < realTotal; i++) {
    var usersLocations = await db
      .select({ locationId: locations.id })
      .from(locations)
      .orderBy(sql`RAND()`)
      .limit(1)
    var usersLocationsString = JSON.stringify(usersLocations)
    var realLocation = usersLocationsString.slice(
      usersLocationsString.indexOf(":") + 1,
      usersLocationsString.indexOf("}")
    )

    await db.insert(userLocations).values([
      {
        locationId: realLocation,
        userId: i,
      },
    ])
  }

  // insert candidates into elections
  for (let i = 100; i < realTotal; i++) {
    await db.insert(electionCandidates).values([
      {
        userId: i,
        electionId: faker.number.int({ min: 1, max: 3 }),
      },
    ])
  }

  // make random votes
  for (let i = 1; i < 100; i++) {
    await db.insert(electionVotes).values([
      {
        id: i,
        userId: i,
        electionId: faker.number.int({ min: 1, max: 3 }),
        politicianId: faker.number.int({ min: 100, max: 149 }),
      },
    ])
  }
}

seed()