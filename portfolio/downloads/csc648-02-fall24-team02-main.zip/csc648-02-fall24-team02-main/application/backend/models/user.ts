import { eq, and, inArray } from "drizzle-orm"
import { db } from "../services/db"
import { userCredentials, users } from "../services/db/schema"
import { RegistrationInput } from "backend/services/auth/auth"

export type User = typeof users.$inferSelect

export async function getUser(id: number) {
  try {
    const user = await db.select().from(users).where(eq(users.id, id))
    return user[0]
  } catch (error) {
    console.error(error)
  }
}

export async function createUser(input: RegistrationInput) {
  try {
    const registerTx = await db.transaction(async (tx) => {
      const userResult = await tx
        .insert(users)
        .values({ firstName: input.firstName, lastName: input.lastName })
        .$returningId()
      const userId = userResult[0].id

      const credentialsResult = await tx
        .insert(userCredentials)
        .values({ email: input.email, password: input.password, userId })
        .$returningId()
    })

    const user = await db
      .select()
      .from(userCredentials)
      .where(eq(userCredentials.email, input.email))
      .innerJoin(users, eq(users.id, userCredentials.userId))
    return user[0].users
  } catch (error) {
    console.error(error)
  }
}

export async function getUserCredentials(email: string) {
  try {
    const result = await db
      .select()
      .from(userCredentials)
      .where(eq(userCredentials.email, email))
    return result[0]
  } catch (error) {
    console.error(error)
  }
}
