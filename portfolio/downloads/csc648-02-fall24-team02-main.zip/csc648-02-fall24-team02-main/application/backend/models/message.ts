import { eq } from "drizzle-orm"
import { db } from "../services/db"
import { messages } from "../services/db/schema"

export type Message = typeof messages.$inferSelect

export async function insertMessage(message: typeof messages.$inferInsert) {
  try {
    await db.insert(messages).values(message)
  } catch (error) {
    console.error(error)
    throw new Error("Failed to insert message")
  }
}

export async function updateMessage(message: Message) {
  try {
    await db.update(messages).set(message).where(eq(messages.id, message.id))
  } catch (error) {
    console.error(error)
  }
}

export async function deleteMessage(message: Message) {
  try {
    await db.delete(messages).where(eq(messages.id, message.id))
  } catch (error) {
    console.error(error)
  }
}

export async function getMessages(userId: number) {
  try {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.receiverId, userId))
  } catch (error) {
    console.error(error)
  }
}
