import { db } from "backend/services/db"
import { locations, politicians, userLocations, users } from "backend/services/db/schema"
import { User } from "./user"
import { eq } from "drizzle-orm"

export type Politician = typeof politicians.$inferSelect

export async function insertPolitician(
  user: typeof users.$inferInsert,
  position: "president" | "senator" | "representative" | "governor" | "mayor",
  city: string = "San Francisco",
  state: string = "CA"
) {
  try {
    await db.transaction(async (tx) => {
      const result = await tx
        .insert(users)
        .values({ ...user, userRole: "politician" })
        .$returningId()
      const userId = result[0].id
      await tx.insert(politicians).values({
        userId,
        positionEnum: position,
      })
      const [{ id: locationId }] = await tx.insert(locations).values({ city, state, country: 'USA' }).$returningId()
      await tx.insert(userLocations).values({ userId, locationId })
    })
  } catch (error) {
    throw Error("failed to create politician")
  }
}

export async function getPoliticians() {
  try {
    const politiciansResult = await db
      .select()
      .from(users)
      .where(eq(users.userRole, "politician"))
      .innerJoin(politicians, eq(users.id, politicians.userId))

    return politiciansResult
  } catch (error) {
    console.error(error)
  }
}
