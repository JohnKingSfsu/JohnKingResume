import { db } from "backend/services/db"
import {
  electionCandidates,
  elections,
  electionVotes,
  politicians,
  users,
} from "backend/services/db/schema"
import { eq, and } from "drizzle-orm"
import { UsersRoundIcon } from "lucide-react"

export type Election = typeof elections.$inferSelect
export type ElectionWithCandidates = Awaited<ReturnType<typeof getElection>>

export async function getElections() {
  try {
    const results = await db.select().from(elections)
    return results
  } catch (error) {
    console.error(error)
  }
}

export async function getElection(electionId: number) {
  try {
    const results = await db
      .select()
      .from(elections)
      .where(eq(elections.id, electionId))
    return results[0]
  } catch (error) {
    console.error(error)
  }
}

export async function getElectionWithCandidates(electionId: number) {
  try {
    const results = await db
      .select()
      .from(elections)
      .where(eq(elections.id, electionId))
      .innerJoin(
        electionCandidates,
        eq(elections.id, electionCandidates.electionId)
      )
      .innerJoin(politicians, eq(electionCandidates.userId, politicians.userId))
      .innerJoin(users, eq(politicians.userId, users.id))
    console.log(results)

    if (results.length === 0) {
      return null
    }

    const election = results[0]
    const candidates = results.map((result) => ({
      candidateId: result.politicians.userId,
      name: result.users.firstName + " " + result.users.lastName,
      party: result.users.party,
      position:
        result.politicians.positionEnum.charAt(0).toUpperCase() +
        result.politicians.positionEnum.slice(1),
      picture: result.users.profilePicture,
    }))

    const votingInfo = {
      ...election.elections,
      candidates,
    }

    return votingInfo
  } catch (error) {
    console.error(error)
  }
}

export async function createElection(
  election: typeof elections.$inferInsert,
  candidateIds: number[]
) {
  try {
    return await db.transaction(async (tx) => {
      const result = await tx.insert(elections).values(election).$returningId()

      await tx.insert(electionCandidates).values(
        candidateIds.map((userId) => ({
          electionId: result[0].id,
          userId,
        }))
      )

      return result
    })
  } catch (error) {
    console.error(error)
    throw error
  }
}

export async function addCandidateToElection(
  electionId: number,
  userId: number
) {
  try {
    await db.insert(electionCandidates).values({ electionId, userId })
  } catch (error) {
    console.error(error)
    throw error
  }
}

export async function getElectionsForUser(userId: number) {
  try {
    const results = await db
      .select()
      .from(elections)
      .innerJoin(
        electionVotes,
        and(
          eq(elections.id, electionVotes.electionId),
          eq(electionVotes.userId, userId)
        )
      )
      .innerJoin(
        politicians,
        eq(electionVotes.politicianId, politicians.userId)
      )
      .innerJoin(users, eq(politicians.userId, users.id))

    return results
  } catch (error) {
    console.error(error)
  }
}
