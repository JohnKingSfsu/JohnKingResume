import { db } from "backend/services/db"
import { comments} from "backend/services/db/schema"
import { eq } from "drizzle-orm"

export type Comment = typeof comments.$inferSelect

export async function insertComment(comment: Comment) {
  try {
    await db.insert(comments).values(comment)
  } catch (error) {
    console.error("Error inserting comment:", error)
  }
}

// Delete a comment
export async function deleteComment(commentId: number) {
  try {
    await db.delete(comments).where(eq(comments.id, commentId))
  } catch (error) {
    console.error("Error deleting comment:", error)
  }
}

// Get comments for a post
export async function getCommentsForPost(postId: number) {
  try {
    return await db.select().from(comments).where(eq(comments.postsId, postId))
  } catch (error) {
    console.error("Error fetching comments for post:", error)
  }
}



