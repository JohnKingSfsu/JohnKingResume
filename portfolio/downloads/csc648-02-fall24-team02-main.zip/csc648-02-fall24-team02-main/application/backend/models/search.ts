import { eq, or, like } from "drizzle-orm"
import { db } from "backend/services/db"
import {
  users,
  politicians,
  locations,
  userLocations,
} from "backend/services/db/schema"

export type UserData = {
  id: string
  firstName: string
  lastName: string
  party: string
  city?: string
  state?: string
  picture: string
}

export async function getSearchedUsers(query: string, filter: string) {
  // This will sanitize the query to prevent SQL injection and other attacks
  if (!query.match(/^[a-zA-Z0-9\s]*$/)) {
    throw new Error("invalid query")
  }
  query = query.trim()
  try {
    switch (filter) {
      case "location":
        return getSearchByLocation(query)
      case "name":
        return getSearchByName(query)
      case "position":
        return getSearchByPosition(query)
      case "party":
        return getSearchByParty(query)
      default:
        throw new Error("invalid filter")
    }
  } catch (error) {
    console.error(error)
  }
}

async function getSearchByLocation(location: string) {
  try {
    const results = await db
      .select()
      .from(locations)
      .where(
        or(
          like(locations.city, `${location}%`),
          like(locations.state, `${location}%`)
        )
      )
      .leftJoin(userLocations, eq(locations.id, userLocations.locationId))
      .leftJoin(users, eq(userLocations.userId, users.id))
      .leftJoin(politicians, eq(users.id, politicians.userId))

    return transformUserData(results)
  } catch (error) {
    console.error(error)
  }
}

async function getSearchByName(name: string) {
  try {
    const results = await db
      .select()
      .from(users)
      .where(
        or(like(users.firstName, `${name}%`), like(users.lastName, `${name}%`))
      )
      .leftJoin(politicians, eq(users.id, politicians.userId))
      .leftJoin(userLocations, eq(users.id, userLocations.userId))
      .leftJoin(locations, eq(userLocations.locationId, locations.id))

    return transformUserData(results)
  } catch (error) {
    console.error(error)
  }
}

async function getSearchByPosition(position: string) {
  try {
    const results = await db
      .select()
      .from(politicians)
      .where(like(politicians.positionEnum, `${position}%`))
      .leftJoin(users, eq(politicians.userId, users.id))
      .leftJoin(userLocations, eq(users.id, userLocations.userId))
      .leftJoin(locations, eq(userLocations.locationId, locations.id))

    return transformUserData(results)
  } catch (error) {
    console.error(error)
  }
}

async function getSearchByParty(party: string) {
  try {
    const results = await db
      .select()
      .from(users)
      .where(like(users.party, `${party}%`))
      .leftJoin(politicians, eq(users.id, politicians.userId))
      .leftJoin(userLocations, eq(users.id, userLocations.userId))
      .leftJoin(locations, eq(userLocations.locationId, locations.id))

    const userResults = transformUserData(results)

    return userResults
  } catch (error) {
    console.error(error)
  }
}

function transformUserData(results: any): UserData {
  return results.map((result: any) => ({
    id: result.users.id,
    firstName: result.users.firstName,
    lastName: result.users.lastName,
    party: result.users.party,
    city: result.locations?.city,
    state: result.locations?.state,
    picture: result.users.profilePicture,
    position: result.politicians?.positionEnum,
  }))
}
