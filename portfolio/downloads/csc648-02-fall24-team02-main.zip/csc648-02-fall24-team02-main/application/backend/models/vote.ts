import { db } from "backend/services/db"
import { elections, users, electionCandidates, electionVotes } from "backend/services/db/schema"
import { and, count, countDistinct, eq } from "drizzle-orm"

export type Vote = typeof electionVotes.$inferInsert

export async function getVotes(electionId: number) {
  try {
    const results = await db
      .select()
      .from(electionVotes)
      .where(eq(electionVotes.electionId, electionId))
    return results
  } catch (error) {
    console.error(error)
  }
}

export async function createVote(vote: Vote) {
  try {
    const results = await db.insert(electionVotes).values(vote).$returningId()
    return results
  } catch (error) {
    if (error instanceof Error && error.message.includes('FOREIGN KEY')) {
      throw new Error('Already Voted')
    }
    console.error(error)
    throw error
  }
}

export async function getVoteByUser(electionId: number, userId: number) {
  try {
    const results = await db
      .select()
      .from(electionVotes)
      .where(
        and(
          eq(electionVotes.electionId, electionId),
          eq(electionVotes.userId, userId)
        )
      )
    console.log(results)
    return results
  } catch (error) {
    console.error(error)
  }
}

export async function getVotesByUser(userId: number) {
  try {
    const results = await db
      .select()
      .from(electionVotes)
      .where(eq(electionVotes.userId, userId))
      .innerJoin(elections, eq(electionVotes.electionId, elections.id))
      .innerJoin(users, eq (electionVotes.politicianId, users.id))
    return results
  } catch (error) {
    console.error(error)
  }
}

export async function getCandidateElectionVotes(
  politicianId: number,
  electionId: number
) {
  try {
    const votes = await db
      .select({ votes: countDistinct(electionVotes.userId) })
      .from(electionVotes)
      .where(
        and(
          eq(electionVotes.electionId, electionId),
          eq(electionVotes.politicianId, politicianId)
        )
      )

    return votes[0]
  } catch (error) {
    console.error(error)
  }
}

export async function getCandidateElectionRating(
  politicianId: number,
  electionId: number
) {
  try {
    const result = await db
      .select({ votes: count(electionVotes) })
      .from(electionVotes)
      .where(eq(electionVotes.electionId, electionId))
    const totalVotes = result[0]
    const votes = await getCandidateElectionVotes(politicianId, electionId)

    if (votes && totalVotes) {
      return votes.votes / totalVotes.votes
    }

    return -1
  } catch (error) {
    console.error(error)
  }
}
