import { db } from "backend/services/db"
import { comments, posts, users } from "backend/services/db/schema"
import { desc, eq } from "drizzle-orm"

export type Post = typeof posts.$inferSelect
export type Comments = typeof comments.$inferSelect

export async function insertPost(post: Post) {
  try {
    await db.insert(posts).values(post)
  } catch (error) {
    console.error("Error inserting post:", error)
  }
}

// Delete a post
export async function deletePost(postId: number) {
  try {
    await db.delete(posts).where(eq(posts.id, postId))
  } catch (error) {
    console.error("Error deleting post:", error)
  }
}

// Get posts by user
export async function getPostsByUser(userId: number) {
  try {
    return await db.select().from(posts).where(eq(posts.posterId, userId))
  } catch (error) {
    console.error("Error fetching posts for user:", error)
  }
}

export async function getPostsbyTime() {
  try {
    return await db.select().from(posts).orderBy(desc(posts.createdAt))
  } catch (error) {
    console.error("Error fetching posts by time:", error)
  }
}

export async function getPostsWithComments() {
  try {
    // Fetch all posts
    const allPosts = await db
    .select({
      postId: posts.id,
      postText: posts.text,
      postCreatedAt: posts.createdAt,
      posterId: posts.posterId,
      authorFirstName: users.firstName,
      authorLastName: users.lastName,
    })
    .from(posts)
    .leftJoin(users, eq(users.id, posts.posterId))
    .orderBy(desc(posts.createdAt));
    
    // For each post, retrieve comments with the author's username
    let postsWithComments = await Promise.all(
      allPosts.map(async (post) => {
        const postComments = await db
          .select({
            commentText: comments.text,
            commentCreatedAt: comments.createdAt,
            authorUsername: users.firstName,
          })
          .from(comments)
          .leftJoin(users, eq(users.id, comments.commenterId))
          .where(eq(comments.postsId, post.postId))
          .orderBy(desc(comments.createdAt)) // Filter comments by post ID
          

        return { post, comments: postComments }
      })
    )

    return postsWithComments
  } catch (error) {
    console.error("Error in getPostsWithComments:", error)
    throw error
  }
}
