import { Authenticator, AuthorizationError } from "remix-auth"
import { sessionStorage } from "./session"
import { FormStrategy } from "remix-auth-form"
import {
  createUser,
  getUser,
  getUserCredentials,
  User,
} from "backend/models/user"
import { hashPassword, verifyPassword } from "./hasher"

export type RegistrationInput = {
  email: string
  password: string
  firstName: string
  lastName: string
}

export let authenticator = new Authenticator<User>(sessionStorage)

authenticator.use(
  new FormStrategy(async ({ context }) => {
    if (!context?.formData) {
      throw new Error("FormData must be provided in the Context")
    }

    const formData = context.formData as FormData
    const email = formData.get("email") as string
    const password = formData.get("password") as string
    if (!email || email.length == 0 || !password || password.length == 0) {
      throw new AuthorizationError("email and password are required")
    }

    return loginUser(email, password)
  }),
  "form-login"
)

authenticator.use(
  new FormStrategy(async ({ context }) => {
    if (!context?.formData) {
      console.log("FormData must be provided in the Context")
      throw new Error("FormData must be provided in the Context")
    }

    const formData = context.formData as FormData
    const email = formData.get("email") as string
    const password = formData.get("password") as string
    const firstName = formData.get("first-name") as string
    const lastName = formData.get("last-name") as string

    if (!email || email.length == 0 || !password || password.length == 0) {
      console.log("email and password are required")
      throw new AuthorizationError("email and password are required")
    }

    return registerUser({ email, password, firstName, lastName })
  }),
  "form-register"
)

async function registerUser(input: RegistrationInput): Promise<User> {
  const existingUser = await getUserCredentials(input.email)
  if (existingUser) {
    console.log("user already exists", input.email)
    throw new AuthorizationError("User already exists")
  }

  const hashedPassword = await hashPassword(input.password)
  const user = await createUser({ ...input, password: hashedPassword })
  if (!user) {
    console.log("could not create user", input.email)
    throw new AuthorizationError("User not created")
  }

  return user
}

async function loginUser(email: string, password: string): Promise<User> {
  const userCredentials = await getUserCredentials(email)
  if (!userCredentials) {
    console.log("could not find user credentials for", email)
    console.log("failed login attempt for", email)
    throw new AuthorizationError("Invalid email or password")
  }

  const valid = await verifyPassword(password, userCredentials.password)
  if (!valid) {
    console.log("invalid password for", email)
    console.log("failed login attempt for", email)
    throw new AuthorizationError("Invalid email or password")
  }

  const user = await getUser(userCredentials.userId)
  if (!user) {
    console.log("could not find user for", email)
    console.log("failed login attempt for", email)
    throw new AuthorizationError("User not found")
  }

  return user
}