import Bun from "bun"

export async function hashPassword(password: string) {
  const hash = await Bun.password.hash(password)
  return hash
}

export async function verifyPassword(password: string, hash: string) {
  const valid = await Bun.password.verify(password, hash)
  return valid
}
