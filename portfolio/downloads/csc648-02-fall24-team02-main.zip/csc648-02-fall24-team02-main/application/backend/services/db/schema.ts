import {
  int,
  mysqlEnum,
  mysqlSchema,
  mysqlTable,
  serial,
  timestamp,
  varchar,
  boolean,
  primaryKey,
} from "drizzle-orm/mysql-core"

export const rolesEnum = mysqlEnum("roles", ["admin", "user", "politician"])
export const positionEnum = mysqlEnum("position", [
  "president",
  "senator",
  "representative",
  "governor",
  "mayor",
])
export const policiesEnum = mysqlEnum("policies", [
  "gun control",
  "healthcare",
  "education",
  "climate change",
  "infrastructure",
  "technology",
  "social justice",
  "foreign policy",
])

export const votingSchema = mysqlSchema("voting")

export const users = mysqlTable("users", {
  id: int().autoincrement().primaryKey(),
  firstName: varchar("first_name", { length: 255 }).notNull(),
  lastName: varchar("last_name", { length: 255 }).notNull(),
  userRole: rolesEnum.default("user"),
  party: varchar("party", { length: 255 }),
  age: int("age"),
  profilePicture: varchar("profile_picture", { length: 255 }),
})

export const userCredentials = mysqlTable("user_credentials", {
  id: int().autoincrement().primaryKey(),
  userId: int("user_id")
    .notNull()
    .references(() => users.id),
  email: varchar("email", { length: 255 }).notNull(),
  password: varchar("password", { length: 255 }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
})

export const messages = mysqlTable("messages", {
  id: int().autoincrement().primaryKey(),
  subject: varchar("subject", { length: 255 }).notNull(),
  text: varchar("text", { length: 255 }).notNull(),
  senderId: int("user_id")
    .notNull()
    .references(() => users.id),
  receiverId: int("receiver_id")
    .notNull()
    .references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
})

export const politicians = mysqlTable("politicians", {
  userId: int("user_id")
    .notNull()
    .references(() => users.id)
    .primaryKey(),
  positionEnum: positionEnum.notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
})

export const policies = mysqlTable("policies", {
  id: int().autoincrement().primaryKey(),
  type: policiesEnum.notNull(),
  politicianId: int("politician_id").references(() => politicians.userId),
  supports: boolean().notNull(),
  description: varchar("description", { length: 255 }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
})

export const locations = mysqlTable("locations", {
  id: int().autoincrement().primaryKey(),
  line1: varchar("line1", { length: 255 }),
  line2: varchar("line2", { length: 255 }),
  city: varchar("city", { length: 255 }).notNull(),
  state: varchar("state", { length: 255 }).notNull(),
  country: varchar("country", { length: 255 }).notNull(),
})

export const elections = mysqlTable("elections", {
  id: int().autoincrement().primaryKey(),
  type: positionEnum.notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: varchar("description", { length: 255 }).notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
})

export const pollingLocations = mysqlTable(
  "polling_locations",
  {
    locationId: int("location_id").references(() => locations.id),
    electionId: int("election_id").references(() => elections.id),
  },
  (table) => ({
    pk: primaryKey({columns: [table.locationId, table.electionId]}),
  })
)

export const userLocations = mysqlTable(
  "user_locations",
  {
    locationId: int("location_id").references(() => locations.id),
    userId: int("user_id").references(() => users.id),
  },
  (table) => ({
    pk: primaryKey({columns: [table.locationId, table.userId]}),
  })
)

export const electionVotes = mysqlTable("election_votes", {
  id: int().autoincrement().primaryKey(),
  userId: int("user_id").references(() => users.id),
  electionId: int("election_id").references(() => elections.id),
  politicianId: int("politician_id").references(() => politicians.userId),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
})

export const electionCandidates = mysqlTable("election_candidates", {
  id: int().autoincrement().primaryKey(),
  userId: int("user_id").references(() => users.id),
  electionId: int("election_id").references(() => elections.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
})

export const posts = mysqlTable("posts", {
  id: int().autoincrement().primaryKey(),
  text: varchar("text", { length: 255 }).notNull(),
  posterId: int("poster_id")
    .notNull()
    .references(() => users.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
})

export const comments = mysqlTable("comments", {
  id: int().autoincrement().primaryKey(),
  text: varchar("text", { length: 255 }).notNull(),
  commenterId: int("commenter_id")
    .notNull()
    .references(() => users.id),
  postsId: int("posts_id")
    .notNull()
    .references(() => posts.id),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
})
