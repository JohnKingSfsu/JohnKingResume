import express from "express"
import { GoogleGenerativeAI } from "@google/generative-ai"
import { db } from "../db/index"
import { elections, policies, politicians, users } from "../db/schema"
import { eq, like, sql } from "drizzle-orm"

const GOOGLE_API_KEY = "AIzaSyDoocgKZeWFy6WacTE4WO0kavGiEfAliA8"

const chatbotRouter = express.Router()
const genAI = new GoogleGenerativeAI(GOOGLE_API_KEY)

const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" })

// Init chat session
const chat = model.startChat({
  history: [
    {
      role: "user",
      parts: [
        {
          text: "You are a helpful assistant specialized in providing information on political topics in the United States. Answer questions related to elections, candidates, and policies.",
        },
      ],
    },
  ],
})

// Helper function to map user query
async function mapQueryMessage(userMessage: string) {
  if (userMessage.toLowerCase().includes("candidate")) {
    return db
      .select({
        name: sql`${users.firstName} ${users.lastName}`.as("name"),
        party: users.party,
        position: politicians.positionEnum,
      })
      .from(politicians)
      .innerJoin(users, eq(politicians.userId, users.id))
      .where(like(users.firstName, `%${userMessage}%`))
  }

  if (userMessage.toLowerCase().includes("election")) {
    return db
      .select({
        title: elections.title,
        description: elections.description,
        startDate: elections.startDate,
        endDate: elections.endDate,
      })
      .from(elections)
      .where(like(elections.title, `%${userMessage}%`))
  }

  if (userMessage.toLowerCase().includes("policy")) {
    return db
      .select({
        type: policies.type,
        description: policies.description,
        supports: policies.supports,
      })
      .from(policies)
      .where(like(policies.type, `%${userMessage}%`))
  }

  return null
}

// Route for standard chat
chatbotRouter.post("/", async (req, res) => {
  const { message } = req.body

  if (!message || typeof message !== "string") {
    return res
      .status(400)
      .json({ message: "Invalid input. Message is required." })
  }

  try {
    let queryResults: any[] = []
    const drizzleQuery = await mapQueryMessage(message)

    if (drizzleQuery) {
      try {
        // Execute the Drizzle query and fetch results
        queryResults = await drizzleQuery
      } catch (dbError) {
        console.error("Database query failed:", dbError)
      }
    }

    const dbContext = queryResults.length
      ? `The query results are: ${JSON.stringify(queryResults)}.`
      : "No relevant data found in the database."
    const prompt = `The user has asked the following question: "${message}". ${dbContext} Provide a clear and concise answer.`

    const result = await chat.sendMessage(prompt)
    const reply = result.response.text() || "I'm here to help!"
    return res.status(200).json({ reply })
  } catch (error) {
    console.error("Error in Gemini AI Chatbot:", error)
    return res.status(500).json({ message: "Failed to process your request." })
  }
})

// Route for streaming chat
chatbotRouter.post("/stream", async (req, res) => {
  const { message } = req.body

  if (!message || typeof message !== "string") {
    return res
      .status(400)
      .json({ message: "Invalid input. Message is required." })
  }

  try {
    let queryResults: any[] = []
    const drizzleQuery = await mapQueryMessage(message)

    if (drizzleQuery) {
      try {
        // Execute the Drizzle query and fetch results
        queryResults = await drizzleQuery
      } catch (dbError) {
        console.error("Database query failed:", dbError)
      }
    }

    const dbContext = queryResults.length
      ? `The query results are: ${JSON.stringify(queryResults)}.`
      : "No relevant data found in the database."
    const prompt = `The user has asked the following question: "${message}". ${dbContext} Provide a clear and concise answer.`

    const result = await chat.sendMessageStream(prompt)

    res.setHeader("Content-Type", "text/plain")
    for await (const chunk of result.stream) {
      const chunkText = chunk.text()
      res.write(chunkText)
    }

    res.end()
  } catch (error) {
    console.error("Error in Gemini AI Chatbot:", error)
    res.status(500).send("Failed to process your request.")
  }
})

export default chatbotRouter
