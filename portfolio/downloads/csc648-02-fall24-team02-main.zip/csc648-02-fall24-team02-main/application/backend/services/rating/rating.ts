import { and, count, eq } from "drizzle-orm"
import { db } from "../db"
import { electionCandidates, elections, electionVotes } from "../db/schema"

export async function getTotalRating(politicianId: number) {
  const RatingNotFound = -1

  const elections = await getPoliticianElections(politicianId)
  if (!elections || elections.length === 0) {
    return RatingNotFound
  }

  const electionsWithRatings = await Promise.all(
    elections.map(async (election) => ({
      rating: await getRatingFromElection(politicianId, election.elections.id),
    }))
  )
  if (!electionsWithRatings || electionsWithRatings.length === 0) {
    return RatingNotFound
  }

  const totalRating = electionsWithRatings.reduce(
    (acc, election) => acc + (Number.isFinite(election.rating) ? election.rating : 0),
    0
  )

  console.log("total rating length", electionsWithRatings.length)
  console.log("total rating", totalRating)
  return (totalRating / electionsWithRatings.length)
}

async function getPoliticianElections(politicianId: number) {
  let result = await db
    .select()
    .from(elections)
    .innerJoin(
      electionCandidates,
      eq(electionCandidates.electionId, elections.id)
    )
    .where(eq(electionCandidates.userId, politicianId))

  return result
}

async function getRatingFromElection(politicianId: number, electionId: number) {
  const totalCountResult = await db
    .select({ count: count() })
    .from(electionVotes)
    .where(eq(electionVotes.electionId, electionId))

  const politicianCountResult = await db
    .select({ count: count() })
    .from(electionVotes)
    .where(
      and(
        eq(electionVotes.politicianId, politicianId),
        eq(electionVotes.electionId, electionId)
      )
    )

  let totalCount = 0
  let politicianCount = 0

  if (totalCountResult[0].count && politicianCountResult[0].count) {
    totalCount = totalCountResult[0].count
    politicianCount = politicianCountResult[0].count
  }

  return politicianCount / totalCount
}
