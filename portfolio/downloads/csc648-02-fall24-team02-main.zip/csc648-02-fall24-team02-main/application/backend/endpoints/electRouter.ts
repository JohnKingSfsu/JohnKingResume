import express from "express"
import {
  createElection,
  createVote,
  Election,
  getElection,
  getElections,
  getVoteByUser,
  Vote,
} from "backend/models/election"

export const electRouter = express.Router()

electRouter.get("/", async (req, res) => {
  try {
    const elections = await getElections()
    res.status(200).json(elections)
  } catch (error) {
    res.status(500).json({ message: error })
  }
})

electRouter.get("/:electionId", async (req, res) => {
  try {
    const electionId = parseInt(req.params.electionId)
    const election = await getElection(electionId)
    res.status(200).json(election)
  } catch (error) {
    res.status(500).json({ message: error })
  }
})

electRouter.post("/", async (req, res) => {
  try {
    const election = req.body as Election
    const newElection = await createElection(election)
    res.status(201).json(newElection)
  } catch (error) {
    res.status(500).json({ message: error })
  }
})

electRouter.post("/:electionId/vote", async (req, res) => {
  try {
    const electionId = parseInt(req.params.electionId)
    const vote = req.body as Vote
    const newVote = await createVote(vote)
    res.status(201).json(newVote)
  } catch (error) {
    res.status(500).json({ message: error })
  }
})

electRouter.get("/:electionId/vote/:userId", async (req, res) => {
  try {
    const electionId = parseInt(req.params.electionId)
    const userId = parseInt(req.params.userId)
    const vote = await getVoteByUser(electionId, userId)
    res.status(200).json(vote)
  } catch (error) {
    res.status(500).json({ message: error })
  }
})
