import express from "express"
import { insertPost, getPostsWithComments } from "backend/models/posts"
import { insertComment } from "backend/models/comments"

export const postRouter = express.Router()

postRouter.get("/retrieval", async (req, res) => {
  const postsWithComments = await getPostsWithComments()

  if (postsWithComments === undefined || postsWithComments === null) {
    return res.status(404).json({ message: "No posts found" })
  }
  res.status(200).json(postsWithComments)
})

postRouter.post("/comment", async (req, res) => {
  const comment = req.body
  const newComment = await insertComment(comment)

  if (newComment === undefined || newComment === null) {
    return res.status(404).json({ message: "Comment not created" })
  }

  res.status(201).json(newComment)
})

postRouter.post("/:userId/post", async (req, res) => {
  const post = req.body
  const newPost = await insertPost(post)

  if (newPost === undefined || newPost === null) {
    return res.status(404).json({ message: "Post not created" })
  }

  res.status(201).json(newPost)
})

export default postRouter
