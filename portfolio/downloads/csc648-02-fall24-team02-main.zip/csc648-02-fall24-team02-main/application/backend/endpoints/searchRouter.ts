import express from "express"
import {
  searchUsers,
  searchLocation,
  searchPosition,
  searchParty,
} from "backend/models/search" // Import search functions

const router = express.Router()

router.get("/search", async (req, res) => {
  const searchTerm = req.query.term || "" // Get the search term from query parameters
  const filter = req.query.filter || "name" // Default filter is 'name'

  try {
    let results
    switch (filter) {
      case "name":
        results = await searchUsers(searchTerm as string) // Search by name
        break
      case "location":
        results = await searchLocation(searchTerm as string) // Search by location
        break
      case "position":
        results = await searchPosition(searchTerm as string) // Search by position
        break
      case "party":
        results = await searchParty(searchTerm as string) // Search by party
        break
      default:
        results = await searchUsers(searchTerm as string) // Fallback to name search
        break
    }

    res.status(200).json(results) // Send the results back
  } catch (error) {
    res.status(500).json({ message: error }) // Handle errors
  }
})

export default router
