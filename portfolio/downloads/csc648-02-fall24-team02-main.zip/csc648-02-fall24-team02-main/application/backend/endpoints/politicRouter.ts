import { getPoliticians } from "backend/models/politician"
import { User } from "backend/models/user"
import express from "express"

export const politicsRouter = express.Router()

politicsRouter.get("/", async (req, res) => {
  const politicians = await getPoliticians()

  if (politicians === undefined || politicians === null) {
    return res.status(404).json({ message: "No politicians found" })
  }

  res.status(200).json(politicians)
})

