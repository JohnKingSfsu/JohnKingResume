import express from "express"
import { getMessages, insertMessage } from "backend/models/message"

export const msgRouter = express.Router()

msgRouter.get("/:userId", async (req, res) => {
  const userId = req.params.userId
  let userIdNum: number

  try {
    userIdNum = parseInt(userId)
  } catch (error) {
    return res.status(400).json({ message: "Invalid user ID" })
  }

  const messages = await getMessages(userIdNum)

  if (messages === undefined || messages === null) {
    return res.status(404).json({ message: "No messages found" })
  }

  res.status(200).json(messages)
})

msgRouter.post("/:userId", async (req, res) => {
  const message = req.body
  const newMessage = await insertMessage(message)

  if (newMessage === undefined || newMessage === null) {
    return res.status(404).json({ message: "Message not created" })
  }

  res.status(201).json(newMessage)
})
