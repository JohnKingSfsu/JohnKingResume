import daisyui from "daisyui"
import type { Config } from "tailwindcss"

export default {
  content: ["./app/**/{**,.client,.server}/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {},
  },
  daisyui: {
    themes: [
      {
        mytheme: {
          primary: "#f8fafc",
          secondary: "#6366f1",
          accent: "#334155",
          neutral: "#e879f9",
          "base-100": "#ffffff",
          info: "#60a5fa",
          success: "#86efac",
          warning: "#fcd34d",
          error: "#fca5a5",      
        },
      },
    ],
  },
  plugins: [require("@tailwindcss/typography"), daisyui],
} satisfies Config
