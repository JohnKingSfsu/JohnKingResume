# Milestones Folder

## This folder is used to store all the necessary documents for each milestone. Some folders may be empty because certain milestones may not contain or need any documents. But certain milestones will required documents to be submitted and then links sent via email to the instructors. These documents should go here in the corresponding folder.
