"""
The code below is just representative of the implementation of a Bot. 
However, this code was not meant to be compiled as it. It is the responsability 
of all the students to modifify this code such that it can fit the 
requirements for this assignments.
"""

import discord
import os
from discord.ext import commands
from models import *

#TODO:  add your Discord Token as a value to your secrets on replit using the DISCORD_TOKEN key
TOKEN = os.environ["DISCORD_TOKEN"]

intents = discord.Intents.all()

bot = commands.Bot(command_prefix='!', intents=discord.Intents.all())


@bot.command(name="test", description="write your database business requirement for this command here")
async def _test(ctx, arg1):
    testModel = TestModel(ctx)
    response = testModel.response()
    await ctx.send(response)


# TODO: complete the following tasks:
#       (1) Replace the commands' names with your own commands
#       (2) Write the description of your business requirement in the description parameter
#       (3) Implement your commands' methods.

#Command in order to allow administrators to register a themepark
@bot.command(name="administrator_update", description="Ability for Administrators of the app to register new themeparks")
async def _command1(ctx, *args):
    work_id = args[0]
    themepark_id = args[1]
    open_status = args[2]
    theme = args[3]
    activities = args[4]
    favorite_selection = args[5]
    name = args[6]
    color = args[7]
    location = args[8]
    popularity_rating = args[9]
    user = args[10]
    
    #add new themepark
    admin_new_themepark = Admin_New_ThemePark(work_id, themepark_id, open_status, theme, activities, favorite_selection, name, color, location, popularity_rating, user)
    if await admin_new_themepark.if_Exists():
        if await admin_new_themepark.if_Admin():
            await admin_new_themepark.insert_themePark()
            response = "Welcome Administrator"
            await ctx.send(response)
            response = "Themepark Added"
            await ctx.send(response)
        else:
            response = "you do not have permission"
            await ctx.send(response)
    else:
        response = "Not administrator"
        await ctx.send(response)



#Command tto allow users to filter themeparks by theme
@bot.command(name="filter_by_theme", description="Implement functionality in order to allow the user to filter different Theme Park by theme.")
async def _command2(ctx, *args):
    theme = args[1]
    user = args[0]

    #filter by theme
    filter_theme = Filter_Theme(user, theme)
    if await(filter_theme.is_user()):
        if await filter_theme.by_theme():
            response = filter_theme.response()
            await ctx.send(response)
        else:
            response = "No theme park found"
            await ctx.send(response)
    else:
        response = "please log in"
        await ctx.send(response)

#Command in order to allow users to filter themeparks by hotel
@bot.command(name="Filter_Hotel", description="Allow users to filter by theme only in order to find hotels with a specific theme, in case the user is not interested in a specific theme park.")
async def _command3(ctx, *args):
    theme = args[1]
    user = args[0]

    #filter by hotel
    filter_hotel = Filter_Hotel(user, theme)
    if await(filter_hotel.is_user()):
        if await filter_hotel.by_theme():
            response = filter_hotel.response()
            await ctx.send(response)
        else:
            response = "No hotel found"
            await ctx.send(response)
    else:
        response = "please log in"
        await ctx.send(response)

#Command to allow users to filter themeparks by activity
@bot.command(name="filter_by_activity", description="Ability for users to filter by activity instead of theme.")
async def _command4(ctx, *args):
    activities = args[1]
    user = args[0]

    #filter by activity
    filter_activities = Filter_By_Activities(user, activities)
    
    if await filter_activities.is_user():
            if await filter_activities.by_activites():
                response = filter_activities.response()
                await ctx.send(response)
            else:
                response = "no parks found"
                await ctx.send(response)
    else:
        response = "please log in"
        await ctx.send(response)

#Command to allow users to select favorite themes
@bot.command(name="favorite_theme", description="Incorporate feature in order to allow the user to select favorite themes indicating “1” as favorite and “0” as not.")
async def _command5(ctx, *args):
    theme = args[1]
    user = args[0]
    rating = args[2]

    #update favorite themes
    update_favorite_theme = Update_Favorite_Theme(user, theme, rating)

    if await update_favorite_theme.is_user():
            if await update_favorite_theme.find_theme():
                await update_favorite_theme.update_theme()
                response = "Favorite theme updated"
                await ctx.send(response)
                response = update_favorite_theme.response()
                await ctx.send(response)
            else:
                response = "no theme found"
                await ctx.send(response)
    else:
        response = "please log in"
        await ctx.send(response)
    return True

#Command to allow users to look at proucts from theme parks
@bot.command(name="view_shop", description="Allow users to look at products sold from a specific shop from different park")
async def _command6(ctx, *args):
    themepark = args[1]
    user = args[0]

    #view shop
    filter_shops = Filter_Shops(user, themepark)

    if await filter_shops.is_user():
            if await filter_shops.by_shop():
                response = filter_shops.response()
                await ctx.send(response)
            else:
                response = "no shop found"
                await ctx.send(response)
    else:
        response = "please log in"
        await ctx.send(response)

#Command in rder to allow users to find food in a certain distance
@bot.command(name="find_food", description="Allow users to find food within a certain distance with a certain theme")
async def _command7(ctx, *args):
    theme = args[2]
    location = args[1]
    user = args[0]

    #find food
    filter_food = Filter_Food(user, location, theme)

    if await(filter_food.is_user()):
        if await filter_food.food():
            response = filter_food.response()
            await ctx.send(response)
        else:
            response = "No food found"
            await ctx.send(response)
    else:
        response = "please log in"
        await ctx.send(response)

#Command to allow app to add employee
@bot.command(name="add_rideemployee", description="Incorporate ability to add new employees to the app, including their name, as well as the ride they work on.")
async def _command8(ctx, *args):
    work_id = args[0]
    fullname = args[1]
    birthday = args[2]
    first_name = args[3]
    last_name = args[4]
    themepark = args[5]

    #add employee
    add_employee = Add_Employee(work_id, fullname, birthday, first_name, last_name, themepark)
    
    if add_employee.add():
        response = "Employee added"
        await ctx.send(response)
    else:
        response = "Employee could not be added"
        await ctx.send(response)


#Command in order to allow administrators to add animals to themeparks
@bot.command(name="add_animal", description="Include ability for administrators to add an animal to a theme park’s profile with name, birthday, location, and theme if requested by theme park.")
async def _command9(ctx, *args):
    work_id = args[0]
    animal_id = args[1]
    name = args[2]
    theme = args[3]
    location = args[4]
    themepark = args[5]

    #add animal
    add_animal = Add_Animal(work_id, animal_id, name, theme, location, themepark)
    if add_animal.if_Exists():
        if add_animal.if_Admin():
            if add_animal.add():
                response = "Animal added"
                await ctx.send(response)
            else:
                response = "Animal could not be added"
                await ctx.send(response)
        else:
            response = "do not have permission"
            await ctx.send(response)
        
    else:
        response = "Please log in"
        await ctx.send(response)

#Command in order to allow users to see if a specific themepark is open
@bot.command(name="is_open", description="Incorporate real park status in order to allow the user to know if the park is available or not.")
async def _command10(ctx, *args):
    user = args[0]
    themepark = args[1]

    #check if themepark is open
    filter_open = Filter_Open(user, themepark)

    if await(filter_open.is_user()):
        await filter_open.is_open()
        response = filter_open.response()
        await ctx.send(response)
    else:
        response = "please log in"
        await ctx.send(response)

#Command to allow users to create an account
@bot.command(name="add_account", description="Creation and customization of a profile with templates for name, user id, and birthday that allow the user to differentiate themselves from other users.")
async def _command11(ctx, *args):
        first_name = args[0]
        user_id = args[1]
        last_name = args[2]
        birthday = args[3]

        #add account
        add_user = Add_User(first_name, user_id, last_name, birthday)
        if add_user.add():
            response = "User added"
            await ctx.send(response)
        else:
            response = "User could not be added"


#Allow administrators to add new theme
@bot.command(name="add_theme", description="Ability for Administrators of the app to register new themes")
async def _command12(ctx, *args):
    work_id = args[0]
    theme_id = args[1]
    name = args[2]
    description = args[3]
    color = args[4]
    favorite_selection = args[5]
    popularity_rating = args[6]
    themepark = args[7]
    
    #add theme
    add_theme = Add_Theme(work_id, theme_id, name, description, color, favorite_selection, popularity_rating, themepark)
    if add_theme.if_Exists():
        if add_theme.if_Admin():
            if add_theme.add():
                response = "Theme added"
                await ctx.send(response)
            else:
                response = "Theme could not be added"
                await ctx.send(response)
        else:
            response = "do not have permission"
            await ctx.send(response)
            return False
    else:
        response = "Please log in"
        await ctx.send(response)

#Command to allow users to add favorite set
@bot.command(name="add_set", description="Incorporate feature in order to allow the user to select favorite themes and activities to add to their profile as a set.")
async def _command13(ctx, *args):
    set_id = args[0]
    theme = args[1]
    activity = args[2]
    account = args[3]
    #add set
    add_set = Add_Set(set_id, theme, activity, account)

    if await add_set.is_user():
        if add_set.add_set():
            response = "Set added"
            await ctx.send(response)
        else:
            response = "set not added"
            await ctx.send(response)
    else:
        response = "please log in"
        await ctx.send(response)

#Command to allow users to find themepark with carnival
@bot.command(name="find_carnival", description="Incorporate functionality in order to allow users to filter themeparks in order to see if there is a carnival")
async def _command14(ctx, *args):
    themepark = args[1]
    user = args[0]
    #find carnival
    filter_carn = Filter_Carn(user, themepark)

    if await filter_carn.is_user():
            if await filter_carn.by_carn():
                response = filter_carn.response()
                await ctx.send(response)
            else:
                response = "themepark not found"
                await ctx.send(response)
    else:
        response = "please log in"
        await ctx.send(response)

#Command to allow users to find characters based on lastname and location
@bot.command(name="find_characters", description="Incorporate a function in order to allow users to filter character by location and last name")
async def _command15(ctx, *args):
    lastname = args[2]
    location = args[1]
    user = args[0]
#find characters
    filter_character = Filter_Character(user, location, lastname)

    if await(filter_character.is_user()):
        if await filter_character.find():
            response = filter_character.response()
            await ctx.send(response)
        else:
            response = "No character found"
            await ctx.send(response)
    else:
        response = "please log in"
        await ctx.send(response)

bot.run(TOKEN)