"""
In this file you must implement all your database models.
If you need to use the methods from your database.py call them
statically. For instance:
       # opens a new connection to your database
       connection = Database.connect()
       # closes the previous connection to avoid memory leaks
       connection.close()
"""


from database import Database, Query


class TestModel:
    """
    This is an object model example. Note that
    this model doesn't implement a DB connection.
    """

    def __init__(self, ctx):
        self.ctx = ctx
        self.author = ctx.message.author.name

    def response(self):
        return f'Hi, {self.author}. I am alive'

#Class to add new park to the database
class Admin_New_ThemePark:
    def __init__(self, work_id, themepark_id, open_status, theme, activities, favorite_selection, name, color, location, popularity_rating, user):
        self.work_id = work_id
        self.themepark_id = themepark_id
        self.open_status = open_status
        self.theme = theme
        self.activities = activities
        self.favorite_selection = favorite_selection
        self.name = name
        self.color = color
        self.location = location
        self.popularity_rating = popularity_rating
        self.user = user


    #Method to see if worker exists
    async def if_Exists(self):
        database = Database()
        query = Query.IF_ADMINISTRATOR
        values = (self.work_id)
        try:
            if (database.select(query, values=values)):
                return True
            else:
                return False
        except Exception as e:
            return False;

    #Method to see if administrator exists
    async def if_Admin(self):
        try:
            if (int(self.work_id) >= 700):
                return True
            else:
                return False
        except Exception as e:
            return False;

    #Insert park into database
    async def insert_themePark(self):
        database = Database()
        values = (self.themepark_id, self.open_status, self.theme, self.activities, self.favorite_selection, self.name, self.color, self.location, self.popularity_rating, self.user)
        query = Query.INSERT_THEMEPARK
        try:
            database.insert(query, values=values)
            return True
        except Exception as e:
            return False;

#Class to filter by theme
class Filter_Theme:
    def __init__(self, user, theme):
        self.user = user
        self.theme = theme

    #Method to filter by theme
    async def by_theme(self):
        database = Database()
        query = Query.FILTER_BY_THEME
        values = (self.theme)
        try:
            self.retname = database.select(query, values=values)
            return self.retname
        except Exception as e:
            return False;

    #Method to see if user
    async def is_user(self):
        database = Database()
        query = Query.IF_USER
        values = (self.user)
        try:
            self.retname = database.select(query, values=values)
            return self.retname
        except Exception as e:
            return False;

            #Send response
    def response(self):
        return f'{self.retname}'

        #Class to filter hotel by theme
class Filter_Hotel:
    def __init__(self, user, theme):
        self.user = user
        self.theme = theme

    #Method to find hotel by theme
    async def by_theme(self):
        database = Database()
        query = Query.FIND_HOTEL
        values = (self.theme)
        try:
            self.retname = database.select(query, values=values)
            return self.retname
        except Exception as e:
            return False;

    #Method to see if user
    async def is_user(self):
        database = Database()
        query = Query.IF_USER
        values = (self.user)
        try:
            self.retname = database.select(query, values=values)
            return self.retname
        except Exception as e:
            return False;
            #Send response
    def response(self):
        return f'{self.retname}'

#Class to filter by activities
class Filter_By_Activities:
    def __init__(self, user, activity):
        self.user = user
        self.activity = activity

    #Method to filter by activities
    async def by_activites(self):
        database = Database()
        query = Query.FILTER_BY_ACTIVITY
        values = (self.activity)
        try:
            print(self.activity)
            self.retname = database.select(query, values=values)
            return self.retname
        except Exception as e:
            return False;

    #Method to see if user
    async def is_user(self):
        database = Database()
        query = Query.IF_USER
        values = (self.user)
        try:
            if database.select(query, values=values):
                return True
            else:
                return False
        except Exception as e:
            return False;

            #Send response
    def response(self):
        return f'{self.retname}'

#Class to filter by favorite theme
class Update_Favorite_Theme:
    def __init__(self, user, theme, rating):
        self.user = user
        self.theme = theme
        self.rating = rating

    #Method to find theme
    async def find_theme(self):
        database = Database()
        query = Query.FIND_THEME
        values = (self.theme)
        try:
            database.update(query, values=values)
            query = Query.PRINT_THEME
            self.retname = database.select(query, values=values)
            return True
        except Exception as e:
            print(f"error in update query: {e}")
            return False;
   
    #Method to update theme
    async def update_theme(self):
        database = Database()
        query = Query.UPDATE_FAVORITE_THEMES
        values = (self.theme, self.rating)
        print(self.theme, self.rating)
        try:
            database.update(query, values=values)
            return True
        except Exception as e:
            print(f"error in update query: {e}")
            return False

    #Method to see if user
    async def is_user(self):
        database = Database()
        query = Query.IF_USER
        values = (self.user)
        try:
            if database.select(query, values=values):
                return True
            else:
                return False
        except Exception as e:
            return False;

    #Method to see if user
    def response(self):
        return f'{self.retname}'


#Class to filter shops by themepark
class Filter_Shops:
    def __init__(self, user, themepark):
        self.user = user
        self.themepark = themepark
        
    #Method to find shops by themepark
    async def by_shop(self):
        database = Database()
        query = Query.FILTER_SHOPS
        values = (self.themepark)
        try:
            self.retname = database.select(query, values=values)
            return self.retname
        except Exception as e:
            return False;

    #Method to see if user
    async def is_user(self):
        database = Database()
        query = Query.IF_USER
        values = (self.user)
        try:
            self.retname = database.select(query, values=values)
            return self.retname
        except Exception as e:
            return False;

            #Send response
    def response(self):
        return f'{self.retname}'

#Class to filter food by location and theme
class Filter_Food:
    def __init__(self, user, location, theme):
        self.user = user
        self.theme = theme
        self.location = location

    #Method to find food by location and theme
    async def food(self):
        database = Database()
        query = Query.FILTER_FOOD
        values = (self.location, self.theme)
        try:
            self.retname = database.select(query, values=values)
            return self.retname
        except Exception as e:
            return False;

    #Method to see if user
    async def is_user(self):
        database = Database()
        query = Query.IF_USER
        values = (self.user)
        try:
            if database.select(query, values=values):
                return True
            else:
                return False
        except Exception as e:
            return False;

            #Send response
    def response(self):
        return f'{self.retname}'

#Class to add employee
class Add_Employee:
    def __init__(self, work_id, fullname, birthday, first_name, last_name, themepark):
        self.work_id = work_id
        self.fullname = fullname
        self.birthday = birthday
        self.first_name = first_name
        self.last_name = last_name
        self.themepark = themepark
        
    #Method to see if employee exists
    def add(self):
        database = Database()
        query = Query.ADD_EMPLOYEE
        values = (self.work_id, self.fullname,
self.birthday, self.first_name, self.last_name, self.themepark)
        
        try:
            database.insert(query, values=values)
            return True
        except Exception as e:
            return False

#Class to add animal to park
class Add_Animal:
    def __init__(self, work_id, animal_id, name, theme, location, themepark):
        self.work_id = work_id
        self.animal_id = animal_id
        self.name = name
        self.theme = theme
        self.location = location
        self.themepark = themepark

    #Method to see if admin exists
    def if_Admin(self):
        try:
            if (int(self.work_id) >= 700):
                return True
            else:
                return False
        except Exception as e:
            return False

    #Method to see if employee exists
    async def if_Exists(self):
        database = Database()
        query = Query.IF_ADMINISTRATOR
        values = (self.work_id)
        try:
            if (database.select(query, values=values)):
                return True
            else:
                return False
        except Exception as e:
            return False;

    #Method to add employee
    def add(self):
        database = Database()
        query = Query.ADD_ANIMAL
        values = (self.animal_id, self.name, self.theme, self.location, self.themepark)


        database.insert(query, values=values)

        return True

#Class to see if park is open
class Filter_Open:
    def __init__(self, user, themepark):
        self.user = user
        self.themepark = themepark

    #Method to see if park is open
    async def is_open(self):
        database = Database()
        query = Query.GET_STATUS
        values = (self.themepark)
        try:
            if database.select(query, values=values):
                self.ret = "Open"
                return True
            else:
                self.ret = "Closed"
        except Exception as e:
            return False;

    #Method to see if user
    async def is_user(self):
        database = Database()
        query = Query.IF_USER
        values = (self.user)
        try:
            if database.select(query, values=values):
                return True
            else:
                return False
        except Exception as e:
            return False;

    #Reponse
    def response(self):
        return self.ret

#Class to add user to the database
class Add_User:
    def __init__(self, first_name, user_id, last_name, birthday):
        self.first_name = first_name
        self.user_id = user_id
        self.last_name = last_name
        self.birthday = birthday

#Method to add user to the database
    def add(self):
        database = Database()
        query = Query.NEW_USER
        values = (self.first_name, self.user_id, self.last_name, self.birthday)


        database.insert(query, values=values)

        return True

        #Class to add new theme
class Add_Theme:
    def __init__(self, work_id, theme_id, name, description, color, favorite_selection, popularity_rating, themepark):
        self.work_id = work_id
        self.theme_id = theme_id
        self.name = name
        self.description = description
        self.color = color
        self.favorite_selection = favorite_selection
        self.popularity_rating = popularity_rating
        self.themepark = themepark

    #Method to see if admin
    def if_Admin(self):
        try:
            if (int(self.work_id) >= 700):
                return True
            else:
                return False
        except Exception as e:
            return False
        
    #Method to see if employee exists
    async def if_Exists(self):
        database = Database()
        query = Query.IF_ADMINISTRATOR
        values = (self.work_id)
        try:
            if (database.select(query, values=values)):
                return True
            else:
                return False
        except Exception as e:
            return False;

    #Method to add theme
    def add(self):
        database = Database()
        query = Query.NEW_THEME
        values = (self.theme_id, self.name, self.description, self.color, self.favorite_selection, self.popularity_rating, self.themepark)


        database.insert(query, values=values)

        return True

#Class to add new set to profile
class Add_Set:
    def __init__(self, set_id, theme, activity, account):
        self.set_id = set_id
        self.theme = theme
        self.activity = activity
        self.account = account

    #Method to see if user
    async def is_user(self):
        database = Database()
        query = Query.IF_USER
        values = (self.account)
        try:
            if database.select(query, values=values):
                return True
            else:
                return False
        except Exception as e:
            return False;

            #Method to add set 
    def add_set(self):
        database = Database()
        query = Query.FAVORITE_SET
        values = (self.set_id, self.theme, self.activity, self.account)
        database.insert(query, values=values)

        

        return True

#Class to filter canival
class Filter_Carn:
    def __init__(self, user, themepark):
        self.user = user
        self.themepark = themepark

    #Class to see if park has carn
    async def by_carn(self):
        database = Database()
        query = Query.FILTER_CARN
        values = (self.themepark)
        try:
            if database.select(query, values=values):
                retname = "Has carnival"
                return True
            else:
                retname = "Does not have carnival"
                return False
        except Exception as e:
            return False;

    #Method to see if user
    async def is_user(self):
        database = Database()
        query = Query.IF_USER
        values = (self.user)
        try:
            self.retname = database.select(query, values=values)
            return self.retname
        except Exception as e:
            return False;

            #Send response
    def response(self):
        return f'{self.retname}'

#Class to filter by character lastname and location
class Filter_Character:
    def __init__(self, user, location, lastname):
        self.user = user
        self.lastname = lastname;
        self.location = location

    #Method to filter by character lastname and location
    async def find(self):
        database = Database()
        query = Query.FILTER_CHARACTER
        values = (self.location, self.lastname)
        try:
            self.retname = database.select(query, values=values)
            return self.retname
        except Exception as e:
            return False;

    #Method to see profile
    async def is_user(self):
        database = Database()
        query = Query.IF_USER
        values = (self.user)
        try:
            if database.select(query, values=values):
                return True
            else:
                return False
        except Exception as e:
            return False;

    #Send response
    def response(self):
        return f'{self.retname}'