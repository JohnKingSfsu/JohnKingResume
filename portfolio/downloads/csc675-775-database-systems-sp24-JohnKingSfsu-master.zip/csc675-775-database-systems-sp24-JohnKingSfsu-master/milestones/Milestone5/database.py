# In this file you must implement your main query methods 
# so they can be used by your database models to interact with your bot.

import os
import pymysql.cursors



#TODO: add the values for these database keys in your secrets on replit
db_host = os.environ["DB_HOST"]
db_username = os.environ["DB_USER"]
db_password = os.environ["DB_PASSWORD"]
db_name = os.environ["DB_NAME"]


class Database:

    # This method was already implemented for you
    def connect(self):
        """
        This method creates a connection with your database
        IMPORTANT: all the environment variables must be set correctly
                   before attempting to run this method. Otherwise, it
                   will throw an error message stating that the attempt
                   to connect to your database failed.
        """
        try:
            conn = pymysql.connect(host=db_host,
                                   port=3306,
                                   user=db_username,
                                   password=db_password,
                                   db=db_name,
                                   charset="utf8mb4", cursorclass=pymysql.cursors.DictCursor)
            print("Bot connected to database {}".format(db_name))
            return conn
        except ConnectionError as err:
            print(f"An error has occurred: {err.args[1]}")
            print("\n")

    #TODO: needs to implement the internal logic of all the main query operations
    def get_response(self, query, values=None, fetch=False, many_entities=False):
        """
        query: the SQL query with wildcards (if applicable) to avoid injection attacks
        values: the values passed in the query
        fetch: If set to True, then the method fetches data from the database (i.e with SELECT)
        many_entities: If set to True, the method can insert multiple entities at a time.
        """
        response = None
        connection = self.connect()
        cursor = connection.cursor()
        if values:
            if many_entities:
                cursor.executemany(query, values)
            else:
                cursor.execute(query, values)
        else:
            cursor.execute(query)
        connection.commit()
        connection.close()
        if fetch:
            response = cursor.fetchall()
        return response

    # the following methods were already implemented for you.
    @staticmethod
    def select(query, values=None, fetch=True):
        database = Database()
        return database.get_response(query, values=values, fetch=fetch)

    @staticmethod
    def insert(query, values=None, many_entities=False):
        database = Database()
        return database.get_response(query, values=values, many_entities=many_entities)

    @staticmethod
    def update(query, values=None):
        database = Database()
        return database.get_response(query, values=values)

    @staticmethod
    def delete(query, values=None):
        database = Database()
        return database.get_response(query, values=values)

class Query:
    #Get park by name
    GET_THEME_PARK_BY_NAME = """
    SELECT * FROM ThemePark tp
    WHERE tp.name = %s;
    """

    #Filter park by activities or theme
    FILTER_BY_ACTIVITIES_OR_THEME = """
    SELECT * FROM ThemePark tp
    WHERE tp.activities = %s OR tp.theme = %s;
    """

    #Find out if user is administrator
    IF_ADMINISTRATOR = """
    SELECT * FROM Administrator ad
    WHERE ad.work_id = %s;
    """

    #insert new themepark
    INSERT_THEMEPARK = """
    INSERT INTO ThemePark (themepark_id, open_status, theme, activities, favorite_selection, name, color, location, popularity_rating, user) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s);
    """

    #Filter park by theme
    FILTER_BY_THEME = """
    SELECT name FROM ThemePark tp
    WHERE tp.theme = %s;
    """

    #Find out if user is a user
    IF_USER = """
    SELECT * FROM User us
    WHERE us.user_id = %s;
    """

    #Find theme
    FIND_THEME = """
    SELECT * FROM Theme t
    WHERE t.theme_id = %s;
    """

    #Filter hotel by theme
    FIND_HOTEL = """
    SELECT name FROM Hotel ht
    WHERE ht.theme = %s;
    """

    #Filter park by activity
    FILTER_BY_ACTIVITY = """
    SELECT name FROM ThemePark tp
    WHERE tp.activities = %s;
    """

    #Update theme's favorite selection
    UPDATE_FAVORITE_THEMES = """
    UPDATE Theme t
    SET t.favorite_selection = %s
    WHERE t.theme_id = %s;
    """

    #Get theme
    PRINT_THEME = """
    SELECT * FROM Theme tp
    WHERE tp.theme_id = %s;
    """

    #Filter shops by themepark
    FILTER_SHOPS = """
    SELECT name FROM Product p
    WHERE p.shop = (
    SELECT shop_id from Shop s
    WHERE s.themepark = %s
    );
    """

    #Filter food by location and theme
    FILTER_FOOD = """
    SELECT * FROM Food t
    WHERE t.location < %s
    AND t.theme = %s;
    """

    #Add employee into themepark
    ADD_EMPLOYEE = """
    INSERT INTO RideEmployee (work_id, fullname, birthday, first_name, last_name, themepark) VALUES (%s, %s, %s, %s, %s, %s);
    """

    #Add animal into themepark
    ADD_ANIMAL = """
    INSERT INTO Animal (animal_id, name, theme, location, themepark) VALUES (%s, %s, %s, %s, %s);
    """

    #Get status of themepark
    GET_STATUS = """
    SELECT * FROM ThemePark t
    WHERE t.themepark_id = %s AND t.open_status = 1;
    """

    #Get employee by id
    GET_EMPLOYEE = """
    SELECT * FROM RideEmployee employee
    WHERE employee.work_id = %s;
    """

    #Insert new user into the database
    NEW_USER ="""
    INSERT INTO User (first_name, user_id, last_name, birthday) VALUES (%s, %s, %s, %s)
    """

    #Find users
    FIND_USER = """
    SELECT user_id FROM User u
    """

    #Insert new theme into themepark
    NEW_THEME = """
    INSERT INTO Theme (theme_id, name, description, color, favorite_selection, popularity_rating, themepark) VALUES (%s, %s, %s, %s, %s, %s, %s)
"""

    #Insert theme and activity into a favorite set
    FAVORITE_SET = """
    INSERT INTO FavoriteSet (set_id, theme, activity, account) VALUES (%s, %s, %s, %s)
    """

    #Filter by themepark to see if it has a carnival
    FILTER_CARN = """
    SELECT name FROM ThemePark themepark
    WHERE themepark_id = (
    SELECT ride_id FROM Carnival m
    WHERE themepark = %s
    );
    """

    #Filter by character's last name and location in any themepark
    FILTER_CHARACTER = """
    SELECT * FROM Actor a
    WHERE a.location < %s
    AND a.last_name = %s;
    """