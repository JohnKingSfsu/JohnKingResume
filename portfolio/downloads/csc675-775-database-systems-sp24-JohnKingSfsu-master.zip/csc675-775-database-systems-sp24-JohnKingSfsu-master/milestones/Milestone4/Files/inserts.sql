/*
This code uses my ThemeParkManagementDB to
populate the databse and give each entity 
values with attributes that a theme park
has.
*/

USE ThemeParkManagementDB;

INSERT INTO Views (user_id, themepark_id) VALUES 
(2,2), 
(3,3), 
(4,4);

INSERT INTO User (first_name, user_id, last_name, birthday) VALUES 
("John T", 1, "King", '2001-02-04 10:02:01'), 
("Lea C.", 2, "King", '1993-02-14 10:22:01'), 
("Pika", 3, "chu", '1997-01-07 10:23:01');

INSERT INTO Theme (theme_id, name, description, color, favorite_selection, popularity_rating, themepark) VALUES 
(1, "fantasy", "A Magic Theme", "purple", 1, 5, 2), 
(2, "Space", "A Space Adventure", "blue", 1, 4.7, 3), 
(3, "plant", "A Plant Adventure", "green", 1, 4.8, 3);

INSERT INTO beSet (set_id) VALUES 
(1), 
(2), 
(3);

INSERT INTO Owns (device_id) VALUES 
(1), 
(2), 
(3);

INSERT INTO Login (user_id) VALUES 
(1), 
(2), 
(3);

INSERT INTO Device (device_id, user) VALUES 
(1, 1), 
(2, 2), 
(3, 3);

INSERT INTO Customer (user_id, name, device) VALUES 
(1, "John", 1), 
(2, "Lea", 2), 
(3, "Pika", 3);

INSERT INTO Account (user_id, username, device_id) VALUES 
(1, "Badtzz-Marus_friend", 1), 
(2, "axolotl", 2), 
(3, "gottaCatchEmAll", 3);


INSERT INTO FavoriteSet (set_id, theme, activity, account) VALUES 
(1, "fantasy", "ride", 2), 
(2, "space", "reading", 1), 
(3, "plants", "walking", 3);


INSERT INTO Win (win_id, carnival) VALUES 
(1, 1), 
(2, 2), 
(3, 3);

INSERT INTO Prize (product_id, theme, prize) VALUES 
(1, "fantasy", 1), 
(2, "space", 2), 
(3, "plants", 3);

INSERT INTO PerformAt (ride_id, actor) VALUES 
(1, 1), 
(2, 2), 
(3, 3);

INSERT INTO Shows (ride_id, actor) VALUES  
(1, 2), 
(2, 2), 
(3, 2);

INSERT INTO Sell (product_id, shop_id) VALUES 
(1, 2), 
(2, 3), 
(3, 4);

INSERT INTO Changes (work_id, status) VALUES 
(700, 1), 
(800, 2), 
(900, 3);

INSERT INTO PopularityRating (rating_id, administrator) VALUES 
(521, 700), 
(522, 700), 
(523, 700);

INSERT INTO OpenStatus (status_id, status, administrator) VALUES 
(2, 1, 700), 
(3, 0, 700), 
(4, 1, 700);

INSERT INTO FavoriteSelection (status_id, status, administrator) VALUES 
(5, 1, 700), 
(6, 0, 700),
(7, 1, 700);

INSERT INTO Prize (product_id, theme, prize) VALUES 
(4, "fantasy", 1), 
(5, "cold", 2), 
(6, "space", 3);

INSERT INTO ThemePark (themepark_id, open_status, theme, activities, favorite_selection, name, color, location, popularity_rating, user) VALUES 
(1, 1, "fantasy", "rides", 1, "Mythical Kingdom", "purple", 5.22, 5, 2), 
(2, 1, "space", "learning", 1, "Space Rocket", "blue", 10.22, 4.7, 2), 
(3, 1, "plants", "shopping", 1, "Island", "green", 12.22, 4.8, 2);

INSERT INTO Administrator (work_id, fullname, first_name, last_name, themepark) VALUES 
(700, DEFAULT, "Brad", "Brad", 2), 
(800, DEFAULT, "Sponge", "Bob", 3), 
(900, DEFAULT, "John", "Bob", 1);

INSERT INTO Product (product_id, name, theme, shop) VALUES 
(2, "elephant toy", "plant", 3), 
(4, "space toy", "space", 2), 
(5, "space animal", "space", 3);

INSERT INTO Shop (shop_id, name, themepark) VALUES 
(1, "Fantasy Shop", 1), 
(2, "space shop", 2), 
(3, "plant shop", 3);


INSERT INTO Animal (animal_id, name, theme, location, themepark) VALUES 
(1, "penguin", "cold", 5.3, 3), 
(2, "penguin two", "cold", 5.4, 3),
(3, "dragon", "fantasy", 5.6, 1);

INSERT INTO RideEmployee (work_id, fullname, birthday, first_name, last_name, themepark) VALUES 
(1, DEFAULT, '1950-02-03', "Jane", "Dim", 1), 
(2, DEFAULT, '1950-02-04', "Jim", "Mim", 2), 
(3, DEFAULT, '1950-2-6', "Jan", "Man", 3);


INSERT INTO Keeper (work_id, first_name, last_name, fullname, animal) VALUES 
(5, "Pom", "Purin", DEFAULT, 2), 
(6, "Badtz", "Maru", DEFAULT, 3),
(7, "MyM", "elody", DEFAULT, 1);

INSERT INTO Animatronic (ride_id, theme, location, ride_employee) VALUES 
(200, "space", 5.3, 1), 
(201, "fantasy", 5.2, 1), 
(202, "plant", 5.3, 1); 

INSERT INTO Ride (ride_id, theme, name, ride_employee) VALUES 
(1, "fantasy", "jungle ride", 1), 
(2, "space", "space ride", 2),
(3, "plant", "plant adventure", 3);

INSERT INTO FoodCartEmployee (work_id, fullname, birthday, first_name, last_name, themepark) VALUES 
(4, DEFAULT, '2000-02-02', "Dave", "Mann", 1), 
(5, DEFAULT, '2000-02-02', "Dav", "Man", 1), 
(6, DEFAULT, '2001-03-03', "Manatee", "Pan", 1);

INSERT INTO MakeFood (food_id, foodcart_employee) VALUES 
(1, 4), 
(2, 5), 
(3, 6);

INSERT INTO Food (food_id, name, theme, location, foodcart_employee) VALUES 
(1, "hotdog", "fantasy", 5.2, 4), 
(2, "space hotdog", "space", 5.3, 5), 
(3, "magic cotton candy", "fantasy", 5.4, 6);

INSERT INTO Hotel (hotel_id, name, location, theme, themepark) VALUES 
(1, "Hotel Castle", 5.2, "fantasy", 1), 
(2, "SpaceShip", 10.2, "space", 2), 
(3, "The Greenhouse", 12.2, "plants", 3);

INSERT INTO Actor (work_id, fullname, birthday, location, first_name, last_name, themepark) VALUES 
(1, "Mickey Mouse", '2000-01-01', 5.2, "Mickey", "Mouse", 1), 
(2, "Minnie Mouse", '2000-01-01', 5.3, "Minnie", "Mouse", 2), 
(3, "Goofy Dog", '2000-01-01', 5.3, "Goofy", "Dog", 3);

INSERT INTO Building (building_id, theme, themepark) VALUES 
(1, "fantasy", 1), 
(2, "space", 2), 
(3, "plants", 3);

INSERT INTO Carnival (ride_id, theme, themepark) VALUES 
(1, "fantasy", 1), 
(2, "space", 2), 
(3, "plants", 3);