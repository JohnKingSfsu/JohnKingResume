# This directory should contain the following files: 

* databasemodel.sql
* inserts.sql
* eer.mwb (from milestone 3)