/**************************************************************
* Class::  CSC-415-04 Spring 2024
* Name:: John King
* Student ID:: 920628771
* GitHub-Name:: JohnKingSfsu
* Project:: CSC415-Device-Driver
*
* File:: King_John_HW6_main.c
*
* Description:: This is a test file to test the device
* drive. It prompts user input to test open, write, read, and
* close.
*
**************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

#define SIZE_OF_STRING 256

int main(int argc, char * argv[])
{
    int fd, info;                            // to keep track of file descriptor
    long n1, n2, n3, command;                // to track result of function calls, and ioctl
    char *inputBuf = malloc(SIZE_OF_STRING); // memory for user input
    char *buf = malloc(SIZE_OF_STRING);      // memory for read file

    // open file for reading and writing in order to translate and get result
    fd = open("/dev/KoreanTranslator", O_RDWR);
    if (fd < 0)
    {
        printf("%d", fd);
        fprintf(stderr, "fopen() failed: %s\n", strerror(errno));
        return -1; // if here could not open
    }
    else
    {
        printf("open success\n");
        printf("Returned from file %d\n", fd);
        printf("\n"); // opened
    }

    // Beginning of translator
    // promt the same in Korean as in English
    // take in user input to see whether they want to translate
    // from Korean to English or English to Korean
    // using ioctl
    printf("Enter \"0\" to translate from English to Korean\n");
    printf("한국어를 영어로 번역하려면 \"1\"을 입력하세요.\n");
    scanf("%ld", &command);
    printf("\n");

    // deal with extra space after input
    getchar();

    // tell driver what to read and write based on command
    n1 = ioctl(fd, command, &info);

    // change prompt based off language
    if (command == 1)
    {
        printf("번역할 단어를 입력하세요\n");
    }
    else if (command == 0)
    {
        printf("enter a line or phrase to translate\n");
    }
    else{
        printf("Please input a 0 or 1");
        return -1; // error
    }

    // get user input to give to write function to translate
    fgets(inputBuf, SIZE_OF_STRING, stdin);
    printf("\n");

    // write input to driver for length of input to translate
    n2 = write(fd, inputBuf, strlen(inputBuf));
    if (n2 < 0)
    {
        printf("No bytes couldd be written\n");
        return -1; // not written
    }
    else
    {
        printf("we wrote %ld byte(s) to file descriptor\n", n2);
        printf("\n"); // written
    }

    // read from device into buf for SIZE OF STRING to get result of translation for printing
    n3 = read(fd, buf, SIZE_OF_STRING);
    if (n3 < 0)
    {
        printf("Could not read\n");
        return -1; // didnt read
    }
    else
    {
        printf("We read %ld byte(s) from file descriptor\n", n3);
        printf("\n"); // read
    }

    // close file descriptor to close driver
    close(fd);

    // Print translated result from buffer
    printf("\"%s\" translated is %s", inputBuf, buf);

    // free allocated memory for strings after printed
    free(inputBuf);
    free(buf);

    return 0; // succeed
}