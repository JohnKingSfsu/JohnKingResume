/**************************************************************
* Class::  CSC-415-04 Spring 2024
* Name:: John King
* Student ID:: 920628771
* GitHub-Name:: JohnKingSfsu
* Project:: CSC415-Device-Driver
*
* File:: KoreanTranslator.c
*
* Description:: This file uses function calls to
* open, release, write, unlocked_ioctl, read, init_module, and
* cleanup_module in order to create, load the device driver
* , and translate words to and from the user.
*
**************************************************************/

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/vmalloc.h>

#include <linux/sched.h>

#define SIZE_OF_STRING 256
#define MY_MAJOR 127
#define MY_MINOR 0
#define DEVICE_NAME "KoreanTranslator"

// declare variables to reconize driver
int major, minor;

// used to initialize system
struct cdev my_cdev;

// set information about driver
MODULE_AUTHOR("John King");
MODULE_DESCRIPTION("A simple English-Korean translator");
MODULE_LICENSE("GPL");

// function declarations used to translate language for device drive
// return 0 on succeeding
int EnglishToKorean(struct file *fs);
int KoreanToEnglish(struct file *fs);

// struct used to keep data from open file descriptor
struct myds
{
    char userInput[SIZE_OF_STRING]; // Input from write user
    char res[SIZE_OF_STRING];       // translated string
    unsigned int command;           // command from ioctl
    int check;
} myds;

// used to open and allocat memory for driver
static int myOpen(struct inode *inode, struct file *fs)
{
    // allocate memory for struct used to translate string
    struct myds *ds;
    ds = vmalloc(sizeof(struct myds));

    // exit if no memory allocate
    if (ds == 0)
    {
        printk(KERN_ERR "could not allocate memory");
        return -1;
    }

    fs->private_data = ds;
    return 0; // succeed
}

// Used to read to user translated string
static ssize_t myRead(struct file *fs, char __user *buf, size_t hsize, loff_t *offp)
{
    // struct to use info from translation
    struct myds *ds;
    ds = (struct myds *)fs->private_data;

    // check which setting was chosen from ioctl to switch language
    if (ds->command == 0)
    {
        ds->check = EnglishToKorean(fs); // English
    }
    else
    {
        ds->check = KoreanToEnglish(fs); // Korean
    }

    if (ds->check != 0)
    {
        printk(KERN_ERR "could not translate");
        return -1;
    }


    // Copy result of translation to user buf for output
    ds->check = copy_to_user(buf, ds->res, strlen(ds->res));


    // if copy to user did not work
    if (ds->check != 0)
    {
        printk(KERN_ERR "could not write user");
        return -1; // error
    }

    // return byte read
    return strlen(ds->res);
}

// Used to get input from user to translate
static ssize_t myWrite(struct file *fs, const char __user *buf, size_t hsize, loff_t *offp)
{

    // struct used to hold translation
    struct myds *ds;
    ds = (struct myds *)fs->private_data;

    // copy translated word from user buffer
    ds->check = copy_from_user(ds->userInput, buf, hsize);

    // if copy did not work
    if (ds->check != 0)
    {
        printk(KERN_ERR "could not copy user");
        return -1; // error
    }

    // return bytes written
    return hsize;
}

// Used to close file after translation done
static int myClose(struct inode *inode, struct file *fs)
{
    // struct used to hold translation
    struct myds *ds;
    ds = (struct myds *)fs->private_data;

    // free memory from struct
    vfree(ds);

    return 0; // succeed
}

// used to change command based off user input, whether to translate from Korean to English
// or English to Korean
static long myIoctl(struct file *fs, unsigned int command, unsigned long lonng)
{
    // struct used to hold translation
    struct myds *ds;
    ds = (struct myds *)fs->private_data;

    // change command in struct to match ioctl
    ds->command = command;

    // return chosen option
    return command;
}
// struct to hold file operation for device driver
struct file_operations fops = {
    .open = myOpen,
    .release = myClose,
    .write = myWrite,
    .unlocked_ioctl = myIoctl,
    .read = myRead,
    .owner = THIS_MODULE,

};

// Used to initiate driver
int init_module(void)
{
    int result, registers;
    dev_t devno;

    // make driver with value set variables
    devno = MKDEV(MY_MAJOR, MY_MINOR);

    // register chardev with device
    registers = register_chrdev_region(devno, 1, DEVICE_NAME);
    printk(KERN_INFO "register chardev succeeded 1: %d\n", registers);
    cdev_init(&my_cdev, &fops);
    my_cdev.owner = THIS_MODULE;
    // add chardev
    result = cdev_add(&my_cdev, devno, 1);
    printk(KERN_INFO "Dev add chardev succeeded 2: %d\n", result);
    printk(KERN_INFO "Welcome\n");

    if (result < 0) // could not register chardev (fai)
    {
        printk(KERN_ERR "register chardev f");
    }

    // cdev_add
    return result;
}

// Used cleanup module device driver
void cleanup_module(void)
{
    // unregister chardev with device name
    dev_t devno;
    devno = MKDEV(MY_MAJOR, MY_MINOR);
    unregister_chrdev_region(devno, 1);
    cdev_del(&my_cdev);

    printk(KERN_INFO "exiting file");
}

// This function is used to tranlsate from English to Korean. It uses strcmp to compare
// the user input to English string, and strcmy to copy the word to the user struct
// return 0 on succeed
int EnglishToKorean(struct file *fs)
{
    // struct used to hold translation
    struct myds *ds;
    ds = (struct myds *)fs->private_data;

    // This block is all the translations used from English to Korean
    if (strcmp(ds->userInput, "Hello\n") == 0)
    {
        strcpy(ds->res, "안녕하세요\n");
    }
    else if (strcmp(ds->userInput, "How are you?\n") == 0) //
    {
        strcpy(ds->res, "어떻게 지내세요?");
    }
    else if (strcmp(ds->userInput, "Goodbye\n") == 0) //
    {
        strcpy(ds->res, "안녕히 계십시오");
    }
    else if (strcmp(ds->userInput, "Food\n") == 0)
    {
        strcpy(ds->res, "음식");
    }
    else if (strcmp(ds->userInput, "Game\n") == 0)
    {
        strcpy(ds->res, "게임");
    }
    else if (strcmp(ds->userInput, "Laugh\n") == 0)
    {
        strcpy(ds->res, "웃다");
    }
    else if (strcmp(ds->userInput, "Sir\n") == 0)
    {
        strcpy(ds->res, "선생님");
    }
    else if (strcmp(ds->userInput, "Good\n") == 0)
    {
        strcpy(ds->res, "좋아요");
    }
    else if (strcmp(ds->userInput, "Thank you\n") == 0)
    {
        strcpy(ds->res, "감사합니다");
    }
    else if (strcmp(ds->userInput, "Please\n") == 0)
    {
        strcpy(ds->res, "주세요");
    }
    else if (strcmp(ds->userInput, "Excuse me\n") == 0)
    {
        strcpy(ds->res, "실례합니다");
    }
    else if (strcmp(ds->userInput, "U.S.\n") == 0)
    {
        strcpy(ds->res, "미국");
    }
    else if (strncmp(ds->userInput, "My name is ", 11) == 0)
    {
        strcpy(ds->res, "내 이름은 (name)입니다");
    }
    else if (strcmp(ds->userInput, "Yes\n") == 0)
    {
        strcpy(ds->res, "네");
    }
    else if (strcmp(ds->userInput, "I\n") == 0)
    {
        strcpy(ds->res, "저");
    }
    else if (strcmp(ds->userInput, "Me\n") == 0)
    {
        strcpy(ds->res, "저");
    }
    else if (strcmp(ds->userInput, "You\n") == 0)
    {
        strcpy(ds->res, "선생님");
    }
    else if (strcmp(ds->userInput, "My\n") == 0)
    {
        strcpy(ds->res, "내");
    }
    else if (strcmp(ds->userInput, "Your\n") == 0)
    {
        strcpy(ds->res, "네");
    }
    else if (strcmp(ds->userInput, "Love\n") == 0)
    {
        strcpy(ds->res, "사랑");
    }
    else if (strcmp(ds->userInput, "I love you\n") == 0)
    {
        strcpy(ds->res, "사랑해요");
    }
    else if (strcmp(ds->userInput, "Music\n") == 0)
    {
        strcpy(ds->res, "음악");
    }
    else if (strcmp(ds->userInput, "Dance\n") == 0)
    {
        strcpy(ds->res, "춤");
    }
    else if (strcmp(ds->userInput, "Listen\n") == 0)
    {
        strcpy(ds->res, "듣다");
    }
    else if (strcmp(ds->userInput, "Like\n") == 0)
    {
        strcpy(ds->res, "좋다");
    }
    else // if none of the options
    {
        strcpy(ds->res, "not able to be translated\n");
    }
    return 0; // succeeding
}

// This function is being used to translate Korean to English based off the icotl and user input
// uses strcmp to see if entered word is in driver, if it is it uses ctrcpy to copy to word
//  to their struct. return 0 on succeeding
int KoreanToEnglish(struct file *fs)
{
    // struct used to hold translation
    struct myds *ds;
    ds = (struct myds *)fs->private_data;

    // struct of translation used to do Korean to English translations and add
    // them to struct at ds->res
    if (strcmp(ds->userInput, "안녕하세요\n") == 0)
    {
        strcpy(ds->res, "Hello");
    }
    else if (strcmp(ds->userInput, "어떻게 지내세요?\n") == 0) //
    {
        strcpy(ds->res, "How are you?");
    }
    else if (strcmp(ds->userInput, "안녕히 계십시오\n") == 0) //
    {
        strcpy(ds->res, "Goodbye");
    }
    else if (strcmp(ds->userInput, "음식\n") == 0)
    {
        strcpy(ds->res, "Food");
    }
    else if (strcmp(ds->userInput, "게임\n") == 0)
    {
        strcpy(ds->res, "Game");
    }
    else if (strcmp(ds->userInput, "웃다\n") == 0)
    {
        strcpy(ds->res, "Laugh");
    }
    else if (strcmp(ds->userInput, "선생님\n") == 0)
    {
        strcpy(ds->res, "Sir");
    }
    else if (strcmp(ds->userInput, "좋아요\n") == 0)
    {
        strcpy(ds->res, "Good");
    }
    else if (strcmp(ds->userInput, "감사합니다\n") == 0)
    {
        strcpy(ds->res, "Thank you");
    }
    else if (strcmp(ds->userInput, "주세요\n") == 0)
    {
        strcpy(ds->res, "Please");
    }
    else if (strcmp(ds->userInput, "실례합니다\n") == 0)
    {
        strcpy(ds->res, "Excuse me");
    }
    else if (strcmp(ds->userInput, "미국\n") == 0)
    {
        strcpy(ds->res, "U.S.");
    }
    else if (strncmp(ds->userInput, "내 이름은", 11) == 0)
    {
        strcpy(ds->res, "My name is");
    }
    else if (strcmp(ds->userInput, "네\n") == 0)
    {
        strcpy(ds->res, "Yes");
    }
    else if (strcmp(ds->userInput, "저\n") == 0)
    {
        strcpy(ds->res, "I");
    }
    else if (strcmp(ds->userInput, "저\n") == 0)
    {
        strcpy(ds->res, "Me");
    }
    else if (strcmp(ds->userInput, "선생님\n") == 0)
    {
        strcpy(ds->res, "You");
    }
    else if (strcmp(ds->userInput, "내\n") == 0)
    {
        strcpy(ds->res, "You");
    }
    else if (strcmp(ds->userInput, "네\n") == 0)
    {
        strcpy(ds->res, "Your");
    }
    else if (strcmp(ds->userInput, "사랑\n") == 0)
    {
        strcpy(ds->res, "Love");
    }
    else if (strcmp(ds->userInput, "사랑해요\n") == 0)
    {
        strcpy(ds->res, "I love you");
    }
    else if (strcmp(ds->userInput, "음악\n") == 0)
    {
        strcpy(ds->res, "Music");
    }
    else if (strcmp(ds->userInput, "춤\n") == 0)
    {
        strcpy(ds->res, "Dance");
    }
    else if (strcmp(ds->userInput, "듣다\n") == 0)
    {
        strcpy(ds->res, "Listen");
    }
    else if (strcmp(ds->userInput, "좋다\n") == 0)
    {
        strcpy(ds->res, "Like");
    }
    else // not in translato
    {
        strcpy(ds->res, "단어를 번역할 수 없습니다\n");
    }
    return 0; // succeeding
}
