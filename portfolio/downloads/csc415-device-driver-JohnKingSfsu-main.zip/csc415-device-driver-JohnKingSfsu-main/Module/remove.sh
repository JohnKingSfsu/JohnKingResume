sudo rm /dev/KoreanTranslator
sudo rmmod KoreanTranslator.ko
