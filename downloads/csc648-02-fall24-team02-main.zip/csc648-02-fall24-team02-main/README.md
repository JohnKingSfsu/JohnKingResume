# csc648 Repository

## Please when ready add your teams application URL or IP to the repository description. This will help with grading. Teams are expected to keep this value up to date.

## Please do the following steps before completing Milestone 0.
1. Change the name of the repository. All that needs to change is the NN to your respective team number. Team numbers whose value is less than 10, please pad with a 0. Ex team 1 is Team01 team 11 is Team11. Please make sure to also remove the username from the repository as well. Teams with incorrectly name repository will have points deducted from their milestone 0 grades.
      - Please follow the naming convention assigned by your instructor.

1. PLEASE REMOVE THE USERNAME FROM THE REPOSITORY NAME!!!

2. Add ALL members of your team to this repository. For it to count, they must ACCEPT the invite.

3. Fill out the table below


| Student Name | Student Email | GitHub Username |
|    :---:     |     :---:     |     :---:       |
| Jia Jun Yang | 920328744@sfsu.edu | theboredkb |                 
| Kaitlyn Yip  |  kyip3@sfsu.edu |   KaitlynYip8 |
| Jisel Rivera | jruiz11@sfsu.edu |   jb307      |
| John King    | 920628771@sfsu.edu | JohnKingSfsu |
| Joshua Francisco | jfrancisco@mail.sfsu.edu | josh399 |
| Eduardo Rodriguez | erodriguez13@mail.sfsu.edu | Eduardo0r4 |
| Steven Brandt| sbrandt1@mail.sfsu.edu| MaKoabra

## NO code needs to be stored in the root of your repository. You may rename the application folder if you like to your team's application name. But all source code related to your team's application should be stored inside the application folder.
